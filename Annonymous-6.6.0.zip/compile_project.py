#!/usr/bin/env python3
import os
import sys
import shutil
import compileall

# Garante suporte a UTF-8 no stdout
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
DIST_DIR = os.path.join(BASE_DIR, "dist_protected")
DIST_CLIENT_DIR = os.path.join(BASE_DIR, "dist_client_protected")

def build_compiled_distribution():
    """Gera a versão compilada e protegida nativamente para a versão do Python em execução.
    Gera duas pastas:
    - dist_protected: Versão Master Completa (com admin_tools.pyc).
    - dist_client_protected: Versão Clientes (sem o painel admin_tools.pyc).
    """
    print("====================================================")
    print(f"   COMPILADOR DE BYTECODE PROTEGIDO v6.5 (Python {sys.version.split()[0]})   ")
    print("====================================================")
    print("\n[1/4] Preparando estrutura de compilação protegida...")

    for d in (DIST_DIR, DIST_CLIENT_DIR):
        if os.path.exists(d):
            try:
                shutil.rmtree(d)
            except Exception:
                pass

    os.makedirs(DIST_DIR, exist_ok=True)

    # Copia todo o projeto para a pasta de distribuição Master
    shutil.copytree(BASE_DIR, DIST_DIR, dirs_exist_ok=True, ignore=shutil.ignore_patterns("dist_protected", "dist_client_protected", "*.pyc", "__pycache__", ".git"))

    print(f"[2/4] Compilando arquivos Python (.py) para Bytecode (.pyc) nativo...")
    compileall.compile_dir(DIST_DIR, force=True, legacy=True)

    print("[3/4] Removendo código-fonte (.py) para proteção contra engenharia reversa...")
    removed_count = 0
    for root, dirs, files in os.walk(DIST_DIR):
        for f in files:
            if f.endswith(".py") and f not in ("install.sh",):
                py_file = os.path.join(root, f)
                try:
                    os.remove(py_file)
                    removed_count += 1
                except Exception:
                    pass

    # Cria a cópia limpa para Clientes sem o arquivo admin_tools.pyc
    print("[4/4] Gerando pacote exclusivo para Clientes ('dist_client_protected')...")
    shutil.copytree(DIST_DIR, DIST_CLIENT_DIR, dirs_exist_ok=True)
    client_admin_file = os.path.join(DIST_CLIENT_DIR, "admin_tools.pyc")
    if os.path.exists(client_admin_file):
        try:
            os.remove(client_admin_file)
        except Exception:
            pass

    print("\n====================================================")
    print(" [OK] COMPILAÇÃO E PROTEÇÃO CONCLUÍDAS COM SUCESSO!")
    print("====================================================")
    print(f"Foram compilados {removed_count} arquivos Python com o Python {sys.version.split()[0]}.")
    print(f"\n📂 Pastas Geradas:")
    print(f"  1. Master Completo: {DIST_DIR} (Com Painel Admin)")
    print(f"  2. Versão Clientes:  {DIST_CLIENT_DIR} (Sem Painel Admin)")
    print("\nPara enviar aos clientes, envie o conteúdo da pasta 'dist_client_protected'.")
    print("O aplicativo funcionará 100% perfeitamente sem o painel admin e sem qualquer erro!")
    print("====================================================")

if __name__ == "__main__":
    build_compiled_distribution()
