import os
import sys
import json
import time
import zipfile
import tempfile
import shutil
import urllib.request
import urllib.parse
import urllib.error
import re

FIREBASE_DB_URL = "https://rastreador-c229f-default-rtdb.firebaseio.com"
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

def get_current_app_version() -> str:
    """Lê a versão atual instalada do aplicativo a partir do arquivo config.json."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                return str(cfg.get("version", "6.5.0")).strip()
        except Exception:
            pass
    return "6.5.0"

def _version_tuple(v_str: str) -> tuple:
    """Converte string de versão (ex: 6.5.0) em tupla comparável de inteiros."""
    try:
        clean_v = re.sub(r'[^0-9.]', '', str(v_str))
        return tuple(map(int, clean_v.split('.')))
    except Exception:
        return (0, 0, 0)

def normalize_direct_download_url(url: str) -> str:
    """Converte automaticamente URLs de serviços de hospedagem (Pixeldrain, Dropbox, Google Drive)
    para links de download direto de arquivos binários .zip.
    """
    clean_url = url.strip()

    pix_match = re.search(r'pixeldrain\.com/u/([a-zA-Z0-9]+)', clean_url)
    if pix_match:
        file_id = pix_match.group(1)
        return f"https://pixeldrain.com/api/file/{file_id}?download"

    if "dropbox.com" in clean_url and "dl=0" in clean_url:
        return clean_url.replace("dl=0", "dl=1")

    gdrive_match = re.search(r'drive\.google\.com/file/d/([a-zA-Z0-9_-]+)', clean_url)
    if gdrive_match:
        file_id = gdrive_match.group(1)
        return f"https://drive.google.com/uc?export=download&id={file_id}"

    return clean_url

def check_for_updates() -> tuple:
    """Consulta no Firebase se há uma versão estritamente MAIOR que a versão atual instalada."""
    url = f"{FIREBASE_DB_URL}/system_update.json"
    req = urllib.request.Request(url, headers={"User-Agent": DEFAULT_USER_AGENT})
    current_ver = get_current_app_version()

    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data_str = resp.read().decode('utf-8')
            if not data_str or data_str == "null":
                return False, "Nenhuma atualização disponível no servidor.", None

            data = json.loads(data_str)
            remote_ver = str(data.get("version", current_ver)).strip()
            zip_url = data.get("download_url", "")
            changelog = data.get("changelog", "Melhorias gerais e correções de segurança.")

            direct_url = normalize_direct_download_url(zip_url)

            if _version_tuple(remote_ver) > _version_tuple(current_ver) and direct_url:
                return True, f"Nova versão v{remote_ver} disponível!", {
                    "version": remote_ver,
                    "download_url": direct_url,
                    "changelog": changelog
                }
            return False, f"Seu sistema já está na versão mais recente (v{current_ver}).", None
    except Exception as e:
        return False, f"Falha ao checar atualizações no servidor: {e}", None

def run_update_flow():
    """Baixa o arquivo ZIP de atualização, extrai no projeto e reinicia o aplicativo.
    Independe de qualquer módulo administrativo para permitir atualizações no cliente final sem admin_tools.py.
    """
    from core.ui import Colors, clear_screen, print_header, print_status, print_box, prompt_input, pause, show_spinner
    from core.banner import get_anonymous_bank_banner

    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Atualizador de Sistema", "Busca de pacote ZIP no Servidor")

    show_spinner("Checando disponibilidade de atualizações no Servidor...", duration=0.8)
    has_update, msg, update_info = check_for_updates()

    if not has_update or not update_info:
        print_status(msg, "warning" if "já está" in msg else "error")
        pause()
        return

    print_box(
        f"🚀 Nova Versão Encontrada: {Colors.BOLD}v{update_info['version']}{Colors.RESET}\n"
        f"🔗 Pacote ZIP: {Colors.CYAN}{update_info['download_url']}{Colors.RESET}\n"
        f"📝 Novidades: {update_info['changelog']}",
        color=Colors.BRIGHT_GREEN,
        title="ATUALIZAÇÃO DISPONÍVEL"
    )

    ans = prompt_input("Deseja baixar, extrair e instalar agora? (SIM/NAO)", default="SIM").upper()
    if ans != "SIM":
        print_status("Instalação de atualização cancelada.", "warning")
        pause()
        return

    tmp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(tmp_dir, "update_package.zip")

    try:
        show_spinner("Baixando pacote ZIP de atualização...", duration=1.2)
        dl_url = normalize_direct_download_url(update_info['download_url'])

        req = urllib.request.Request(dl_url, headers={"User-Agent": DEFAULT_USER_AGENT})
        with urllib.request.urlopen(req, timeout=15) as resp, open(zip_path, 'wb') as out_file:
            shutil.copyfileobj(resp, out_file)

        print_status("Download concluído com sucesso!", "success")

        if not zipfile.is_zipfile(zip_path):
            raise ValueError("O link baixado retornou HTML em vez de um arquivo .ZIP binário válido. Certifique-se de usar um link de download direto.")

        show_spinner("Extraindo arquivos e atualizando a instalação...", duration=1.0)
        extract_tmp = os.path.join(tmp_dir, "extracted")
        os.makedirs(extract_tmp, exist_ok=True)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_tmp)

        top_items = os.listdir(extract_tmp)
        source_dir = extract_tmp
        if len(top_items) == 1 and os.path.isdir(os.path.join(extract_tmp, top_items[0])):
            source_dir = os.path.join(extract_tmp, top_items[0])

        for item in os.listdir(source_dir):
            s_item = os.path.join(source_dir, item)
            d_item = os.path.join(BASE_DIR, item)
            if os.path.isdir(s_item):
                shutil.copytree(s_item, d_item, dirs_exist_ok=True)
            else:
                shutil.copy2(s_item, d_item)

        print_status("Arquivos atualizados com sucesso!", "success")
        shutil.rmtree(tmp_dir, ignore_errors=True)

        print_box("🎉 Sistema Atualizado com Sucesso!\nO aplicativo será reiniciado em instantes.", color=Colors.BRIGHT_GREEN, title="INSTALAÇÃO CONCLUÍDA")
        time.sleep(1.5)
        
        python_executable = sys.executable
        os.execv(python_executable, [python_executable] + sys.argv)

    except Exception as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        print_status(f"Falha durante a instalação da atualização: {e}", "error")
        pause()

def publish_update_to_firebase(version: str, download_url: str, changelog: str) -> tuple:
    """Publica os dados de um arquivo ZIP de atualização no Firebase convertendo automaticamente para link direto."""
    direct_url = normalize_direct_download_url(download_url)

    payload = {
        "version": version.strip(),
        "download_url": direct_url,
        "changelog": changelog.strip()
    }

    url = f"{FIREBASE_DB_URL}/system_update.json"
    req_bytes = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=req_bytes, headers={"Content-Type": "application/json", "User-Agent": DEFAULT_USER_AGENT}, method="PUT")
    
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            return True, f"Atualização v{version} publicada com sucesso no servidor!\nURL Direta Configurada: {direct_url}"
    except Exception as e:
        return False, f"Erro ao publicar atualização no Firebase: {e}"
