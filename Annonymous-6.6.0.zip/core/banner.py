from core.ui import Colors, get_terminal_width

def get_anonymous_bank_banner() -> str:
    """Banner minimalista, executivo e 100% responsivo para Annonymous Bank v6.5."""
    w = get_terminal_width()
    border_len = max(20, w - 2)
    border = "═" * border_len
    
    title = "⚡ ANONYMOUS BANK ⚡"
    subtitle = "SISTEMA PIX COMMERCE v6.5"
    if border_len < 32:
        subtitle = "PIX COMMERCE v6.5"

    t_len = len(title)
    s_len = len(subtitle)

    t_l = max(0, (border_len - t_len) // 2)
    t_r = max(0, border_len - t_len - t_l)
    
    s_l = max(0, (border_len - s_len) // 2)
    s_r = max(0, border_len - s_len - s_l)

    banner = (
        f"{Colors.BRIGHT_CYAN}╔{border}╗\n"
        f"║{' ' * t_l}{Colors.BOLD}{Colors.BRIGHT_WHITE}{title}{Colors.RESET}{Colors.BRIGHT_CYAN}{' ' * t_r}║\n"
        f"║{' ' * s_l}{Colors.BRIGHT_GREEN}{subtitle}{Colors.RESET}{Colors.BRIGHT_CYAN}{' ' * s_r}║\n"
        f"╚{border}╝{Colors.RESET}"
    )
    return banner
