#!/usr/bin/env python3
import os
import sys
import json
import time

# Suporte universal a UTF-8 no terminal
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, BASE_DIR)

from core.ui import Colors, clear_screen, print_header, print_status, print_box, prompt_input, pause
from core.banner import get_anonymous_bank_banner
from core.db import init_db
from core.auth import (
    verify_license,
    get_user_balance_from_firebase,
    show_user_profile,
    check_and_display_notifications,
    start_license_watchdog
)
from core.notifier import send_native_notification
from modules.misticpay import MisticPayManager
from modules.transaction_history import run_history_menu
from admin_tools import run_update_flow, run_admin_panel, _admin_manage_withdrawals

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

def load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "app_name": "Annonymous Bank PIX Terminal",
        "version": "6.5.0"
    }

def login_screen() -> dict:
    """Tela de login e validação de licença comercial via Servidor."""
    while True:
        clear_screen()
        print(get_anonymous_bank_banner())
        
        login_box = (
            f"🔐 {Colors.BOLD}SISTEMA DE AUTENTICAÇÃO COMERCIAL SAAS{Colors.RESET}\n"
            f"Informe seu usuário e senha cadastrados para acessar o seu painel."
        )
        print_box(login_box, color=Colors.BRIGHT_CYAN, title="LOGIN ANONYMOUS BANK")

        username = prompt_input("Usuário")
        if not username:
            continue
        password = prompt_input("Senha", password=True)

        print_status("Autenticando e verificando licença no Servidor...", "info")
        is_valid, data_or_msg = verify_license(username, password)

        if is_valid:
            user_info = data_or_msg
            role_str = "ADMINISTRADOR MASTER" if user_info.get("role") == "admin" else "USUÁRIO COMUM"
            welcome_msg = (
                f"🎉 {Colors.BOLD}BEM-VINDO, {user_info['username'].upper()}!{Colors.RESET} ({role_str})\n\n"
                f"💰 Seu Saldo em Conta: {Colors.BRIGHT_GREEN}R$ {user_info['balance']:.2f}{Colors.RESET}\n"
                f"✔️ Status da Licença:  {Colors.BRIGHT_GREEN}ATIVA / VÁLIDA{Colors.RESET}\n"
                f"⏳ Tempo Restante:     {Colors.BRIGHT_GREEN}{user_info['time_left_formatted']}{Colors.RESET}\n"
                f"📅 Expira em:          {user_info['expiration_formatted']}"
            )
            print_box(welcome_msg, color=Colors.BRIGHT_GREEN, title="ACESSO AUTORIZADO")
            print_status("Licença autenticada com sucesso!", "success")
            time.sleep(1.5)
            return user_info
        else:
            err_box = (
                f"❌ {Colors.BOLD}FALHA DE AUTENTICAÇÃO / LICENÇA{Colors.RESET}\n\n"
                f"{data_or_msg}\n\n"
                f"{Colors.DIM}Adquira ou renove sua licença com o suporte oficial.{Colors.RESET}"
            )
            print_box(err_box, color=Colors.BRIGHT_RED, title="ACESSO NEGADO")
            pause()

def main():
    # Inicializa banco de dados SQLite interno
    init_db()

    # Exibe a Tela de Login e Validação de Licença Comercial
    user_session = login_screen()
    username = user_session["username"]
    role = user_session.get("role", "user")
    is_admin = role == "admin"

    # Inicia o Robô Sentinel de Checagem em Segundo Plano (Daemon Thread)
    start_license_watchdog(username)

    config = load_config()
    mistic_mgr = MisticPayManager(config, CONFIG_FILE)

    # Checa notificações pendentes logo após o login
    clear_screen()
    print(get_anonymous_bank_banner())
    check_and_display_notifications(username)

    while True:
        clear_screen()
        print(get_anonymous_bank_banner())
        
        # Busca o saldo individual atualizado do usuário no Servidor
        user_balance = get_user_balance_from_firebase(username)
        
        is_cfg = mistic_mgr.is_configured()
        api_status_str = "CONECTADO" if is_cfg else "NÃO CONFIGURADO"

        account_card = (
            f"👤 Usuário: {Colors.BOLD}{Colors.BRIGHT_WHITE}{username}{Colors.RESET} ({'ADMIN' if is_admin else 'CLIENTE'}) │ API: {Colors.BRIGHT_CYAN}{api_status_str}{Colors.RESET}\n"
            f"💰 Seu Saldo Individual: {Colors.BRIGHT_GREEN}{Colors.BOLD}R$ {user_balance:.2f}{Colors.RESET} {Colors.DIM}(Taxa Fixa Gateway: R$ 0,50){Colors.RESET}"
        )
        print_box(account_card, color=Colors.BRIGHT_GREEN, title="PAINEL DA CONTA SAAS")

        if not is_admin:
            # MENU DO USUÁRIO COMUM
            print(f"\n  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 📥 Cobrar via PIX (Gerar QR Code)")
            print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] 📤 Solicitar Saque / Resgate (Requer Aprovação Admin)")
            print(f"  [{Colors.BRIGHT_MAGENTA}3{Colors.RESET}] 📊 Extrato & Histórico das Minhas Transações")
            print(f"  [{Colors.BRIGHT_YELLOW}4{Colors.RESET}] 💰 Meu Saldo & Perfil")
            print(f"  [{Colors.BRIGHT_BLUE}5{Colors.RESET}] ⏱️  Monitorar Cobrança por ID")
            print(f"  [{Colors.BRIGHT_CYAN}6{Colors.RESET}] 🔔 Testar Notificação Push Android")
            print(f"  [{Colors.BRIGHT_YELLOW}7{Colors.RESET}] 🚀 Atualizar Sistema")
            print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] 🚪 Sair")

            choice = prompt_input("\nOpção", default="1")

            if choice == "0":
                print(f"\n{Colors.BRIGHT_CYAN}Saindo do Anonymous Bank. Até logo!{Colors.RESET}\n")
                sys.exit(0)
            elif choice == "1":
                mistic_mgr.generate_pix(current_username=username)
            elif choice == "2":
                mistic_mgr.request_user_withdrawal(current_username=username)
            elif choice == "3":
                run_history_menu(mistic_mgr)
            elif choice == "4":
                show_user_profile(username)
            elif choice == "5":
                tx_id = prompt_input("Informe o ID da transação a monitorar")
                if tx_id:
                    mistic_mgr.monitor_transaction(tx_id, current_username=username)
            elif choice == "6":
                send_native_notification("🔔 Annonymous Bank", f"Olá {username}, notificações ativas!")
                print_status("Notificação enviada ao celular!", "success")
                pause()
            elif choice == "7":
                run_update_flow()
            else:
                print_status("Opção inválida.", "error")
        else:
            # MENU DO ADMINISTRADOR MASTER
            print(f"\n  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 📥 Cobrar via PIX (Gerar QR Code)")
            print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] 📤 Saque Direto Master")
            print(f"  [{Colors.BRIGHT_YELLOW}3{Colors.RESET}] 📋 Aprovar / Recusar Saques de Usuários (PENDENTES)")
            print(f"  [{Colors.BRIGHT_MAGENTA}4{Colors.RESET}] 📊 Extrato & Histórico Global de Transações")
            print(f"  [{Colors.BRIGHT_BLUE}5{Colors.RESET}] 👤 Meu Saldo & Perfil do Usuário")
            print(f"  [{Colors.BRIGHT_WHITE}6{Colors.RESET}] ⚙️  Credenciais da API")
            print(f"  [{Colors.BRIGHT_CYAN}7{Colors.RESET}] 🔑 Painel Admin (Gerenciar Licenças, Notificações & Senha)")
            print(f"  [{Colors.BRIGHT_YELLOW}8{Colors.RESET}] 🚀 Atualizar Sistema")
            print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] 🚪 Sair")

            choice = prompt_input("\nOpção", default="1")

            if choice == "0":
                print(f"\n{Colors.BRIGHT_CYAN}Saindo do Anonymous Bank. Até logo!{Colors.RESET}\n")
                sys.exit(0)
            elif choice == "1":
                mistic_mgr.generate_pix(current_username=username)
            elif choice == "2":
                mistic_mgr.send_pix_master_admin()
            elif choice == "3":
                _admin_manage_withdrawals(mistic_mgr)
            elif choice == "4":
                run_history_menu(mistic_mgr)
            elif choice == "5":
                print_header("Consulta de Perfil")
                print(" 1. Ver Meu Saldo & Perfil Individual")
                print(" 2. Ver Saldo & Perfil Master da API Gateway")
                p_opt = prompt_input("Opção", default="1")
                if p_opt == "2":
                    mistic_mgr.show_account_info()
                else:
                    show_user_profile(username)
            elif choice == "6":
                mistic_mgr.configure_credentials()
                config = load_config()
                mistic_mgr = MisticPayManager(config, CONFIG_FILE)
            elif choice == "7":
                run_admin_panel(mistic_mgr)
            elif choice == "8":
                run_update_flow()
            else:
                print_status("Opção inválida.", "error")

if __name__ == "__main__":
    main()
