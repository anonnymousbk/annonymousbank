#!/usr/bin/env python3
import os
import sys
import time
import zipfile
import urllib.request
import tempfile
import shutil

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, BASE_DIR)

from core.ui import Colors, clear_screen, print_header, print_status, print_box, prompt_input, pause
from core.banner import get_anonymous_bank_banner
from core.updater import check_for_updates, publish_update_to_firebase
from core.auth import (
    register_user_in_firebase,
    get_all_users_from_firebase,
    toggle_user_status_in_firebase,
    delete_user_from_firebase,
    verify_admin_password,
    change_admin_password_in_firebase,
    send_user_notification,
    send_broadcast_notification
)
from core.withdrawals import (
    get_pending_withdrawals,
    approve_withdrawal_request,
    reject_withdrawal_request
)

def run_update_flow():
    """Baixa o arquivo ZIP de atualização, extrai no projeto e reinicia o aplicativo.
    Suporta tanto ZIPs com os arquivos diretos quanto ZIPs contendo a pasta do aplicativo.
    """
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Atualizador de Sistema", "Busca de pacote ZIP no Servidor")

    print_status("Checando disponibilidade de atualizações no Servidor...", "info")
    has_update, msg, update_info = check_for_updates()

    if not has_update or not update_info:
        print_status(msg, "warning" if "já está" in msg else "error")
        pause()
        return

    print_box(
        f"🚀 Nova Versão Encontrada: {Colors.BOLD}v{update_info['version']}{Colors.RESET}\n"
        f"🔗 Pacote ZIP: {Colors.CYAN}{update_info['download_url']}{Colors.RESET}\n"
        f"📝 Novidades: {update_info['changelog']}",
        color=Colors.BRIGHT_GREEN,
        title="ATUALIZAÇÃO DISPONÍVEL"
    )

    ans = prompt_input("Deseja baixar, extrair e instalar agora? (SIM/NAO)", default="SIM").upper()
    if ans != "SIM":
        print_status("Instalação de atualização cancelada.", "warning")
        pause()
        return

    tmp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(tmp_dir, "update_package.zip")

    try:
        print_status("Baixando pacote ZIP de atualização...", "info")
        urllib.request.urlretrieve(update_info['download_url'], zip_path)
        print_status("Download concluído com sucesso!", "success")

        print_status("Extraindo arquivos e atualizando a instalação...", "info")
        extract_tmp = os.path.join(tmp_dir, "extracted")
        os.makedirs(extract_tmp, exist_ok=True)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_tmp)

        top_items = os.listdir(extract_tmp)
        source_dir = extract_tmp
        if len(top_items) == 1 and os.path.isdir(os.path.join(extract_tmp, top_items[0])):
            source_dir = os.path.join(extract_tmp, top_items[0])

        for item in os.listdir(source_dir):
            s_item = os.path.join(source_dir, item)
            d_item = os.path.join(BASE_DIR, item)
            if os.path.isdir(s_item):
                shutil.copytree(s_item, d_item, dirs_exist_ok=True)
            else:
                shutil.copy2(s_item, d_item)

        print_status("Arquivos atualizados com sucesso!", "success")
        shutil.rmtree(tmp_dir, ignore_errors=True)

        print_box("🎉 Sistema Atualizado com Sucesso!\nO aplicativo será reiniciado em instantes.", color=Colors.BRIGHT_GREEN, title="INSTALAÇÃO CONCLUÍDA")
        time.sleep(2)
        
        python_executable = sys.executable
        os.execv(python_executable, [python_executable] + sys.argv)

    except Exception as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        print_status(f"Falha durante a instalação da atualização: {e}", "error")
        pause()

def run_admin_panel(mistic_mgr=None):
    """Painel Administrativo com visual executivo e autenticação master online."""
    clear_screen()
    print(get_anonymous_bank_banner())
    
    auth_card = (
        f"🔑 {Colors.BOLD}CONTROLE DE SEGURANÇA MASTER ONLINE{Colors.RESET}\n"
        f"Esta área é estritamente reservada ao administrador do sistema."
    )
    print_box(auth_card, color=Colors.BRIGHT_CYAN, title="AUTENTICAÇÃO ADMINISTRATIVA")

    entered_pass = prompt_input("Senha Master do Administrador", password=True)
    
    print_status("Verificando autenticação no servidor...", "info")
    if not verify_admin_password(entered_pass):
        print_status("Acesso Negado: Senha Master incorreta!", "error")
        pause()
        return

    while True:
        clear_screen()
        print(get_anonymous_bank_banner())
        
        master_card = (
            f"👤 Perfil: {Colors.BOLD}{Colors.BRIGHT_WHITE}ADMINISTRADOR MASTER{Colors.RESET} │ Servidor: {Colors.BRIGHT_CYAN}ONLINE SEGURO{Colors.RESET}\n"
            f"⚡ Controle de Usuários, Notificações Push, Aprovação de Saques e Licenciamento"
        )
        print_box(master_card, color=Colors.BRIGHT_GREEN, title="PAINEL ADMINISTRATIVO MASTER v6.5")

        print(f"\n  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 👤 Cadastrar / Renovar Licença de Usuário")
        print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] 📋 Listar Licenças, Saldos & Prazos")
        print(f"  [{Colors.BRIGHT_YELLOW}3{Colors.RESET}] 📥 Aprovar / Recusar Solicitações de Saque (PENDENTES)")
        print(f"  [{Colors.BRIGHT_MAGENTA}4{Colors.RESET}] 📢 Enviar Notificação (Individual ou Coletiva)")
        print(f"  [{Colors.BRIGHT_BLUE}5{Colors.RESET}] 🔒 Bloquear / Liberar Acesso de Usuário")
        print(f"  [{Colors.BRIGHT_RED}6{Colors.RESET}] 🗑️ Excluir Licença de Usuário")
        print(f"  [{Colors.BRIGHT_WHITE}7{Colors.RESET}] 🔑 Alterar Senha Master do Administrador (Online)")
        print(f"  [{Colors.BRIGHT_YELLOW}8{Colors.RESET}] 🚀 Publicar Nova Atualização (ZIP no Servidor)")
        print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] ⬅️ Voltar ao Menu Principal")

        choice = prompt_input("\nOpção", default="1")

        if choice == "0":
            break
        elif choice == "1":
            _admin_register_user()
        elif choice == "2":
            _admin_list_users()
        elif choice == "3":
            _admin_manage_withdrawals(mistic_mgr)
        elif choice == "4":
            _admin_send_notifications()
        elif choice == "5":
            _admin_toggle_user()
        elif choice == "6":
            _admin_delete_user()
        elif choice == "7":
            _admin_change_password()
        elif choice == "8":
            _admin_publish_update()
        else:
            print_status("Opção inválida.", "error")

def _admin_register_user():
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Cadastrar / Renovar Licença", "Licenciamento Comercial")
    
    username = prompt_input("Nome do Usuário")
    if not username: return
    password = prompt_input("Senha de Acesso")
    if not password: return

    print(f"\n{Colors.BOLD}Perfil / Papel de Acesso:{Colors.RESET}")
    print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] Usuário Comum (user)")
    print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] Administrador (admin)")
    r_opt = prompt_input("Perfil", default="1")
    role = "admin" if r_opt == "2" else "user"

    print(f"\n{Colors.BOLD}Escolha a unidade do prazo de validade:{Colors.RESET}")
    print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] Minutos")
    print(f"  [{Colors.BRIGHT_GREEN}2{Colors.RESET}] Horas")
    print(f"  [{Colors.BRIGHT_GREEN}3{Colors.RESET}] Dias")
    print(f"  [{Colors.BRIGHT_GREEN}4{Colors.RESET}] Semanas")
    print(f"  [{Colors.BRIGHT_GREEN}5{Colors.RESET}] Meses")
    
    u_opt = prompt_input("\nOpção (1-5)", default="3")
    unit_map = {"1": "MINUTOS", "2": "HORAS", "3": "DIAS", "4": "SEMANAS", "5": "MESES"}
    unit = unit_map.get(u_opt, "DIAS")

    try:
        amount = int(prompt_input(f"Quantidade de {unit}", default="30"))
        if amount <= 0: raise ValueError()
    except ValueError:
        print_status("Quantidade inválida.", "error")
        pause()
        return

    print_status("Gravando licença no Servidor...", "info")
    ok, msg = register_user_in_firebase(username, password, amount, unit, role=role)
    if ok:
        print_status(msg, "success")
        res_box = (
            f"👤 Usuário:   {Colors.BOLD}{username}{Colors.RESET}\n"
            f"🔑 Perfil:    {role.upper()}\n"
            f"⏱️ Validade:  {amount} {unit}"
        )
        print_box(res_box, color=Colors.BRIGHT_GREEN, title="LICENÇA REGISTRADA")
    else:
        print_status(msg, "error")
    pause()

def _admin_list_users():
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Usuários, Saldos & Validades", "Servidor de Licenças")
    
    print_status("Buscando no Servidor...", "info")
    users = get_all_users_from_firebase()

    if not users:
        print_status("Nenhum usuário cadastrado no Servidor.", "warning")
    else:
        print(f"\n Total de Licenças: {Colors.BOLD}{len(users)}{Colors.RESET}\n")
        print(f" {'USUÁRIO':<14} | {'PAPEL':<7} | {'SALDO':<10} | {'STATUS':<9} | {'EXPIRA EM'}")
        print(" ─" * 70)
        for u in users:
            st = u.get("status_label", "DESCONHECIDO")
            st_color = Colors.BRIGHT_GREEN if st == "ATIVO" else Colors.BRIGHT_RED
            role_str = u.get("role", "user").upper()
            bal_str = f"R$ {u.get('balance', 0.0):.2f}"
            print(f" {u.get('username',''):<14} | {role_str:<7} | {Colors.BRIGHT_GREEN}{bal_str:<10}{Colors.RESET} | {st_color}{st:<9}{Colors.RESET} | {u.get('expiration_date','')}")
        print(" ─" * 70)
    pause()

def _admin_manage_withdrawals(mistic_mgr=None):
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Aprovação de Saques de Usuários", "Fila de Solicitações Pendentes")
    
    print_status("Buscando solicitações no Servidor...", "info")
    pending = get_pending_withdrawals()

    if not pending:
        print_status("Nenhuma solicitação de saque pendente no momento!", "success")
        pause()
        return

    print(f"\n Solicitações Pendentes: {Colors.BOLD}{len(pending)}{Colors.RESET}\n")
    for idx, req in enumerate(pending, 1):
        print(f" [{Colors.BRIGHT_GREEN}{idx}{Colors.RESET}] ID: {req['id']} │ Usuário: {Colors.BOLD}{req['username']}{Colors.RESET} │ Valor: {Colors.BRIGHT_GREEN}R$ {req['amount']:.2f}{Colors.RESET} │ Chave: {req['pix_key']} ({req['pix_type']})")
    
    print(f"\n{Colors.BOLD}Opções:{Colors.RESET}")
    print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] Aprovar Solicitação (Executar PIX via Rede)")
    print(f"  [{Colors.BRIGHT_RED}2{Colors.RESET}] Recusar Solicitação (Reembolsar Saldo ao Usuário)")
    print(f"  [{Colors.BRIGHT_WHITE}0{Colors.RESET}] Voltar")

    act = prompt_input("\nAção", default="1")
    if act == "0": return

    try:
        req_num = int(prompt_input(f"Selecione o número do saque (1-{len(pending)})"))
        if not (1 <= req_num <= len(pending)): raise ValueError()
        target_req = pending[req_num - 1]
    except ValueError:
        print_status("Seleção inválida.", "error")
        pause()
        return

    req_id = target_req["id"]
    u_name = target_req["username"]
    amt = target_req["amount"]

    if act == "1":
        print(f"\n{Colors.BRIGHT_YELLOW}⚠️ CONFIRMAÇÃO DE APROVAÇÃO MASTER:{Colors.RESET}")
        print(f" O valor de {Colors.BRIGHT_GREEN}R$ {amt:.2f}{Colors.RESET} será enviado via PIX para a chave {target_req['pix_key']} ({target_req['pix_type']}).")
        conf = prompt_input("\nConfirmar envio e aprovação? (SIM/NAO)", default="NAO").upper()
        if conf != "SIM": return

        if not mistic_mgr or not mistic_mgr.is_configured():
            print_status("Credenciais da API não configuradas!", "error")
            pause()
            return

        print_status("Processando saque na Rede...", "info")
        ok, msg = approve_withdrawal_request(req_id, mistic_mgr)
        if ok:
            print_status(msg, "success")
        else:
            print_status(msg, "error")
        pause()

    elif act == "2":
        reason = prompt_input("Motivo da recusa", default="Dados incorretos ou inconsistência")
        conf = prompt_input(f"Confirmar recusa e reembolsar R$ {amt:.2f} para {u_name}? (SIM/NAO)", default="NAO").upper()
        if conf != "SIM": return

        print_status("Recusando e reembolsando saldo no Servidor...", "info")
        ok, msg = reject_withdrawal_request(req_id, reason=reason)
        if ok:
            print_status(msg, "success")
        else:
            print_status(msg, "error")
        pause()

def _admin_send_notifications():
    """Envia notificações individuais ou coletivas (broadcast) para os aplicativos dos clientes."""
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Sistema de Notificações Online", "Emissão de Push Alerts")

    print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 👤 Notificação Individual (Para 1 Usuário Específico)")
    print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] 📢 Comunicado Coletivo (Broadcast para TODOS os Usuários)")
    print(f"  [{Colors.BRIGHT_WHITE}0{Colors.RESET}] ⬅️ Voltar")

    n_opt = prompt_input("\nOpção (1-2)", default="1")
    if n_opt == "0": return

    if n_opt == "1":
        username = prompt_input("Nome do Usuário Destinatário")
        if not username: return
        title = prompt_input("Título do Alerta", default="Aviso Importante do Administrador")
        msg_text = prompt_input("Mensagem da Notificação")
        if not msg_text: return

        print_status("Enviando notificação individual via servidor...", "info")
        ok, msg = send_user_notification(username, title, msg_text)
        if ok:
            print_status(msg, "success")
        else:
            print_status(msg, "error")
        pause()

    elif n_opt == "2":
        title = prompt_input("Título do Comunicado Geral", default="Comunicado da Administração")
        msg_text = prompt_input("Mensagem para TODOS os clientes")
        if not msg_text: return

        conf = prompt_input("Confirmar envio coletivo para TODOS os usuários? (SIM/NAO)", default="NAO").upper()
        if conf != "SIM": return

        print_status("Disparando comunicado coletivo via servidor...", "info")
        ok, msg = send_broadcast_notification(title, msg_text)
        if ok:
            print_status(msg, "success")
        else:
            print_status(msg, "error")
        pause()

def _admin_change_password():
    """Altera a Senha Master do Administrador diretamente no banco de dados online."""
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Alterar Senha Master do Administrador", "Armazenamento 100% Online no Servidor")

    old_pass = prompt_input("Senha Master Atual", password=True)
    new_pass = prompt_input("Nova Senha Master", password=True)
    confirm_pass = prompt_input("Confirme a Nova Senha Master", password=True)

    if new_pass.strip() != confirm_pass.strip():
        print_status("As novas senhas não coincidem!", "error")
        pause()
        return

    print_status("Gravando nova Senha Master no servidor online seguro...", "info")
    ok, msg = change_admin_password_in_firebase(old_pass, new_pass)
    if ok:
        print_status(msg, "success")
    else:
        print_status(msg, "error")
    pause()

def _admin_toggle_user():
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Bloquear / Liberar Licença", "Gerenciamento de Acesso")
    
    username = prompt_input("Nome do Usuário")
    if not username: return

    print(f"\n{Colors.BOLD}Ação:{Colors.RESET}")
    print(f"  [{Colors.BRIGHT_RED}1{Colors.RESET}] Bloquear Acesso")
    print(f"  [{Colors.BRIGHT_GREEN}2{Colors.RESET}] Liberar Acesso")
    act_opt = prompt_input("\nOpção (1-2)", default="1")
    active = act_opt == "2"

    ok = toggle_user_status_in_firebase(username, active)
    if ok:
        print_status(f"Status do usuário '{username}' alterado para {'LIBERADO' if active else 'BLOQUEADO'}.", "success")
    else:
        print_status("Falha ao alterar status no Servidor.", "error")
    pause()

def _admin_delete_user():
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Excluir Licença", "Remoção Definitiva do Servidor")
    
    username = prompt_input("Nome do Usuário a Excluir")
    if not username: return

    confirm = prompt_input(f"Tem certeza que deseja apagar '{username}'? (SIM/NAO)", default="NAO").upper()
    if confirm == "SIM":
        ok = delete_user_from_firebase(username)
        if ok:
            print_status("Licença excluída com sucesso!", "success")
        else:
            print_status("Falha ao excluir licença.", "error")
    else:
        print_status("Operação cancelada.", "warning")
    pause()

def _admin_publish_update():
    clear_screen()
    print(get_anonymous_bank_banner())
    print_header("Publicar Nova Atualização no Servidor", "Publicador de Pacotes ZIP")
    
    ver = prompt_input("Nova Versão (Ex: 6.5.0)")
    if not ver: return
    url = prompt_input("URL Direta do Arquivo ZIP de Atualização")
    if not url: return
    logs = prompt_input("Descrição das novidades da versão", default="Melhorias gerais e correções de segurança.")

    print_status("Publicando pacote no Servidor...", "info")
    ok, msg = publish_update_to_firebase(ver, url, logs)
    if ok:
        print_status(msg, "success")
    else:
        print_status(msg, "error")
    pause()

if __name__ == "__main__":
    run_admin_panel()
