import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "transactions.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Inicializa o banco de dados SQLite interno."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id TEXT PRIMARY KEY,
        client_tx_id TEXT,
        tx_type TEXT NOT NULL,          -- 'CASHIN' ou 'CASHOUT'
        amount REAL NOT NULL,
        payer_name TEXT,
        payer_doc TEXT,
        pix_key TEXT,
        pix_type TEXT,
        description TEXT,
        status TEXT NOT NULL,           -- 'PENDENTE', 'COMPLETO', 'FALHA'
        copy_paste TEXT,
        qr_url TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """)
    conn.commit()
    conn.close()

def save_transaction(tx_data: dict):
    """Salva ou atualiza uma transação no banco interno."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    tx_id = tx_data.get("id") or tx_data.get("transactionId")
    client_tx_id = tx_data.get("client_tx_id", "")
    tx_type = tx_data.get("tx_type", "CASHIN")
    amount = float(tx_data.get("amount", 0.0))
    payer_name = tx_data.get("payer_name", "N/A")
    payer_doc = tx_data.get("payer_doc", "N/A")
    pix_key = tx_data.get("pix_key", "")
    pix_type = tx_data.get("pix_type", "")
    description = tx_data.get("description", "")
    status = tx_data.get("status", "PENDENTE")
    copy_paste = tx_data.get("copy_paste", "")
    qr_url = tx_data.get("qr_url", "")
    created_at = tx_data.get("created_at") or now

    cursor.execute("""
    INSERT INTO transactions (id, client_tx_id, tx_type, amount, payer_name, payer_doc, pix_key, pix_type, description, status, copy_paste, qr_url, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
        status = excluded.status,
        amount = excluded.amount,
        updated_at = excluded.updated_at
    """, (tx_id, client_tx_id, tx_type, amount, payer_name, payer_doc, pix_key, pix_type, description, status, copy_paste, qr_url, created_at, now))
    
    conn.commit()
    conn.close()

def update_status(tx_id: str, new_status: str):
    """Atualiza o status de uma transação pelo ID."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("UPDATE transactions SET status = ?, updated_at = ? WHERE id = ?", (new_status, now, tx_id))
    conn.commit()
    conn.close()

def search_transactions(query: str = None, status_filter: str = None, type_filter: str = None, limit: int = 50) -> list:
    """Busca avançada com filtros por texto, status e tipo."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    
    sql = "SELECT * FROM transactions WHERE 1=1"
    params = []

    if query:
        q = f"%{query.strip()}%"
        sql += " AND (id LIKE ? OR payer_name LIKE ? OR payer_doc LIKE ? OR pix_key LIKE ? OR description LIKE ?)"
        params.extend([q, q, q, q, q])

    if status_filter:
        sql += " AND UPPER(status) = UPPER(?)"
        params.append(status_filter.strip())

    if type_filter:
        sql += " AND UPPER(tx_type) = UPPER(?)"
        params.append(type_filter.strip())

    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    cursor.execute(sql, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_transaction_by_id(tx_id: str) -> dict:
    """Obtém detalhes completos de uma transação."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transactions WHERE id = ? OR client_tx_id = ?", (tx_id, tx_id))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def delete_transaction_by_id(tx_id: str) -> bool:
    """Apaga uma transação do banco interno pelo ID."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM transactions WHERE id = ? OR client_tx_id = ?", (tx_id, tx_id))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0

def clear_all_transactions() -> int:
    """Limpa todo o histórico de transações do banco interno."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM transactions")
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected
