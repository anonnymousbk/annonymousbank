import os
import subprocess

def send_native_notification(title: str, message: str, priority: str = "high"):
    """Envia uma notificação push nativa na barra do Android usando termux-api."""
    try:
        # Vibra o dispositivo (800ms)
        subprocess.Popen(['termux-vibrate', '-d', '800'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

    try:
        # Envia notificação para a barra de status do Android
        cmd = [
            'termux-notification',
            '-t', title,
            '-c', message,
            '--priority', priority,
            '--sound'
        ]
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False
