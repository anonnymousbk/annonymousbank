import os
import sys
import shutil
import textwrap
import re

class Colors:
    """Códigos ANSI para estilização premium e neon do terminal."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"
    
    # Cores Primárias
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    
    # Cores Premium Neon
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

def remove_ansi(text: str) -> str:
    """Remove códigos ANSI para cálculo exato da largura do texto."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def get_terminal_width() -> int:
    """Retorna a largura responsiva do terminal ajustada para telas de celulares e PCs (mínimo 36, máximo 72)."""
    try:
        cols = shutil.get_terminal_size((56, 20)).columns
        return max(36, min(cols - 2, 72))
    except Exception:
        return 56

def clear_screen():
    """Limpa o terminal de forma limpa."""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(title: str, subtitle: str = None):
    """Imprime um cabeçalho compacto e 100% responsivo."""
    w = get_terminal_width()
    divider = "─" * w
    print(f"{Colors.BRIGHT_CYAN}{divider}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BRIGHT_WHITE}  {title.upper()}{Colors.RESET}")
    if subtitle:
        print(f"{Colors.DIM}  {subtitle}{Colors.RESET}")
    print(f"{Colors.BRIGHT_CYAN}{divider}{Colors.RESET}")

def print_box(text: str, color=Colors.BRIGHT_GREEN, title: str = None):
    """Renderiza caixas 100% responsivas com quebra automática de linha sem cortar letras ou bordas."""
    w = get_terminal_width()
    max_content_w = max(20, w - 4)

    raw_lines = text.split('\n')
    formatted_lines = []

    for raw_line in raw_lines:
        plain_len = len(remove_ansi(raw_line))
        if plain_len <= max_content_w:
            formatted_lines.append(raw_line)
        else:
            # Quebra automática respeitando palavras
            plain_text = remove_ansi(raw_line)
            wrapped = textwrap.wrap(plain_text, width=max_content_w)
            for chunk in wrapped:
                formatted_lines.append(chunk)

    top_title = f" {title} " if title else ""
    if len(top_title) > (w - 4):
        top_title = top_title[:w-6] + ".. "

    rem = max(0, w - len(top_title) - 2)
    rem_left = max(1, rem // 2)
    rem_right = max(1, rem - rem_left)

    top_border = f"┌{'─' * rem_left}{top_title}{'─' * rem_right}┐"
    bot_border = f"└{'─' * (w - 2)}┘"

    print(f"{color}{top_border}{Colors.RESET}")
    for line in formatted_lines:
        clean_len = len(remove_ansi(line))
        pad = max(0, w - 4 - clean_len)
        print(f"{color}│{Colors.RESET} {line}{' ' * pad} {color}│{Colors.RESET}")
    print(f"{color}{bot_border}{Colors.RESET}")

def print_status(message: str, status_type: str = "info"):
    """Exibe mensagens de status limpas e elegantes."""
    if status_type == "success":
        icon = f"{Colors.BRIGHT_GREEN}[✔]{Colors.RESET}"
    elif status_type == "warning":
        icon = f"{Colors.BRIGHT_YELLOW}[⚠️]{Colors.RESET}"
    elif status_type == "error":
        icon = f"{Colors.BRIGHT_RED}[✖]{Colors.RESET}"
    else:
        icon = f"{Colors.BRIGHT_CYAN}[ℹ]{Colors.RESET}"
    print(f"{icon} {message}")

def prompt_input(label: str, default: str = None, password: bool = False) -> str:
    """Prompt elegante e limpo com suporte a responsividade."""
    default_str = f" [{Colors.DIM}{default}{Colors.RESET}]" if default else ""
    prompt_text = f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}➜ {label}{default_str}: {Colors.RESET}"
    
    if password:
        import getpass
        res = getpass.getpass(prompt_text)
    else:
        res = input(prompt_text)
    
    return res.strip() if res and res.strip() else (default or "")

def pause():
    """Pausa para leitura do usuário."""
    prompt_input("\n[ Pressione ENTER para continuar ]")
