import os
import sys
import shutil

class Colors:
    """Códigos ANSI para estilização premium e neon do terminal."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"
    
    # Cores Primárias
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    
    # Cores Premium Neon
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

def get_terminal_width() -> int:
    """Retorna a largura responsiva do terminal ajustada para telas mobile (mínimo 42, máximo 70)."""
    try:
        cols = shutil.get_terminal_size((60, 20)).columns
        return max(42, min(cols - 2, 70))
    except Exception:
        return 56

def clear_screen():
    """Limpa o terminal de forma limpa."""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(title: str, subtitle: str = None):
    """Imprime um cabeçalho compacto e responsivo."""
    w = get_terminal_width()
    divider = "─" * w
    print(f"{Colors.BRIGHT_CYAN}{divider}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BRIGHT_WHITE}  {title.upper()}{Colors.RESET}")
    if subtitle:
        print(f"{Colors.DIM}  {subtitle}{Colors.RESET}")
    print(f"{Colors.BRIGHT_CYAN}{divider}{Colors.RESET}")

def print_box(text: str, color=Colors.BRIGHT_GREEN, title: str = None):
    """Renderiza caixas responsivas com suporte a largura dinâmica."""
    w = get_terminal_width()
    lines = text.split('\n')

    top_title = f" {title} " if title else ""
    rem = w - len(top_title) - 2
    rem_left = max(1, rem // 2)
    rem_right = max(1, rem - rem_left)

    top_border = f"┌{'─' * rem_left}{top_title}{'─' * rem_right}┐"
    bot_border = f"└{'─' * (w - 2)}┘"

    print(f"{color}{top_border}{Colors.RESET}")
    for line in lines:
        # Truncamento/formatação limpa para evitar quebra de linha feia
        clean_len = len(remove_ansi(line))
        pad = max(0, w - 4 - clean_len)
        print(f"{color}│{Colors.RESET} {line}{' ' * pad} {color}│{Colors.RESET}")
    print(f"{color}{bot_border}{Colors.RESET}")

def remove_ansi(text: str) -> str:
    """Remove códigos ANSI para cálculo exato da largura de texto."""
    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def print_status(message: str, status_type: str = "info"):
    """Exibe mensagens de status limpas e elegantes."""
    if status_type == "success":
        icon = f"{Colors.BRIGHT_GREEN}[✔]{Colors.RESET}"
    elif status_type == "warning":
        icon = f"{Colors.BRIGHT_YELLOW}[⚠️]{Colors.RESET}"
    elif status_type == "error":
        icon = f"{Colors.BRIGHT_RED}[✖]{Colors.RESET}"
    else:
        icon = f"{Colors.BRIGHT_CYAN}[ℹ]{Colors.RESET}"
    print(f"{icon} {message}")

def prompt_input(label: str, default: str = None, password: bool = False) -> str:
    """Prompt elegante e limpo."""
    default_str = f" [{Colors.DIM}{default}{Colors.RESET}]" if default else ""
    prompt_text = f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}➜ {label}{default_str}: {Colors.RESET}"
    
    if password:
        import getpass
        res = getpass.getpass(prompt_text)
    else:
        res = input(prompt_text)
        
    val = res.strip()
    return val if val else (default if default else "")

def pause():
    """Pausa simples."""
    print(f"\n{Colors.DIM}[ Enter para continuar ]{Colors.RESET}")
    input()
