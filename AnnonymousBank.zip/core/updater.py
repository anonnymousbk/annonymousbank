import json
import urllib.request
import urllib.parse
import urllib.error

FIREBASE_DB_URL = "https://rastreador-c229f-default-rtdb.firebaseio.com"
CURRENT_VERSION = "5.0.0"
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

def check_for_updates() -> tuple:
    """Consulta no Firebase se há uma nova versão disponível."""
    url = f"{FIREBASE_DB_URL}/system_update.json"
    req = urllib.request.Request(url, headers={"User-Agent": DEFAULT_USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data_str = resp.read().decode('utf-8')
            if not data_str or data_str == "null":
                return False, "Nenhuma atualização disponível no servidor.", None

            data = json.loads(data_str)
            remote_ver = data.get("version", CURRENT_VERSION)
            zip_url = data.get("download_url", "")
            changelog = data.get("changelog", "Melhorias gerais e correções de segurança.")

            if remote_ver != CURRENT_VERSION and zip_url:
                return True, f"Nova versão v{remote_ver} disponível!", {
                    "version": remote_ver,
                    "download_url": zip_url,
                    "changelog": changelog
                }
            return False, f"Seu sistema já está na versão mais recente (v{CURRENT_VERSION}).", None
    except Exception as e:
        return False, f"Falha ao checar atualizações no servidor: {e}", None

def publish_update_to_firebase(version: str, download_url: str, changelog: str) -> tuple:
    """Publica os dados de um arquivo ZIP de atualização no Firebase."""
    payload = {
        "version": version.strip(),
        "download_url": download_url.strip(),
        "changelog": changelog.strip(),
        "updated_at": json.dumps(None)
    }

    url = f"{FIREBASE_DB_URL}/system_update.json"
    req_bytes = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=req_bytes, headers={"Content-Type": "application/json", "User-Agent": DEFAULT_USER_AGENT}, method="PUT")
    
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            return True, f"Atualização v{version} enviada ao servidor Firebase com sucesso!"
    except Exception as e:
        return False, f"Erro ao publicar atualização no Firebase: {e}"
