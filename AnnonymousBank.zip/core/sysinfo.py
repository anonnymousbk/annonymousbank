import os
import platform
import shutil
import socket
import subprocess
import json

def get_system_summary() -> dict:
    """Coleta métricas e informações do sistema no Termux."""
    info = {}
    
    # OS & Termux
    info['os'] = platform.system()
    info['node'] = platform.node()
    info['arch'] = platform.machine()
    info['python_version'] = platform.python_version()
    
    # Armazenamento (Disco)
    try:
        total, used, free = shutil.disk_usage("/")
        info['storage_total_gb'] = round(total / (1024**3), 2)
        info['storage_used_gb'] = round(used / (1024**3), 2)
        info['storage_free_gb'] = round(free / (1024**3), 2)
        info['storage_percent'] = round((used / total) * 100, 1)
    except Exception:
        info['storage_percent'] = "N/A"

    # Endereço IP Local
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        info['local_ip'] = s.getsockname()[0]
        s.close()
    except Exception:
        info['local_ip'] = "Desconectado"

    # Termux-API: Bateria (Se instalado)
    info['battery'] = "Indisponível (instale termux-api)"
    if shutil.which("termux-battery-status"):
        try:
            res = subprocess.check_output(["termux-battery-status"], timeout=2)
            data = json.loads(res.decode('utf-8'))
            percentage = data.get("percentage", "N/A")
            status = data.get("status", "")
            info['battery'] = f"{percentage}% ({status})"
        except Exception:
            pass

    return info
