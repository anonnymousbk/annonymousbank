import json
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timedelta
from core.ui import Colors, print_header, print_status, print_box, pause

FIREBASE_DB_URL = "https://rastreador-c229f-default-rtdb.firebaseio.com"
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
GATEWAY_FEE = 0.50  # Taxa fixa de R$ 0,50 da MisticPay

DEFAULT_GATEWAY_CONFIG = {
    "client_id": "ci_e6j2m85ubnxfpcn",
    "client_secret": "cs_rnm37jkgohyiojypboku3scbu",
    "api_base_url": "https://api.misticpay.com/api"
}

def _firebase_req(endpoint: str, method: str = "GET", data: dict = None) -> tuple:
    """Função REST para o Firebase Realtime Database."""
    url = f"{FIREBASE_DB_URL}/{endpoint.lstrip('/')}.json"
    headers = {"User-Agent": DEFAULT_USER_AGENT, "Content-Type": "application/json"}
    
    body_bytes = None
    if data is not None:
        body_bytes = json.dumps(data).encode('utf-8')

    req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=6) as response:
            res = response.read().decode('utf-8')
            return response.status, json.loads(res) if res and res != "null" else None
    except urllib.error.HTTPError as e:
        return e.code, None
    except Exception:
        return 500, None

def get_cloud_gateway_config() -> dict:
    """Busca as credenciais da API salvas com segurança no servidor Firebase em tempo de execução."""
    status, cfg = _firebase_req("app_config/gateway", method="GET")
    if status == 200 and isinstance(cfg, dict) and cfg.get("client_id"):
        return cfg
    
    # Se ainda não existirem no Firebase, inicializa os valores padrão com segurança
    _firebase_req("app_config/gateway", method="PUT", data=DEFAULT_GATEWAY_CONFIG)
    return DEFAULT_GATEWAY_CONFIG

def save_cloud_gateway_config(client_id: str, client_secret: str, api_base_url: str = None) -> bool:
    """Salva/Atualiza as credenciais da API diretamente no servidor online Firebase."""
    current = get_cloud_gateway_config()
    payload = {
        "client_id": client_id.strip(),
        "client_secret": client_secret.strip(),
        "api_base_url": (api_base_url or current.get("api_base_url", "https://api.misticpay.com/api")).strip()
    }
    status, _ = _firebase_req("app_config/gateway", method="PUT", data=payload)
    return status in (200, 201)

def verify_license(username: str, password: str) -> tuple:
    """Verifica credenciais, papel (role), saldo individual e validade da licença no Firebase."""
    username_clean = username.strip().lower()
    if not username_clean or not password:
        return False, "Informe usuário e senha."

    status, user_data = _firebase_req(f"users/{username_clean}", method="GET")

    if status != 200 or not user_data:
        return False, "Usuário não cadastrado ou não encontrado."

    if user_data.get("password") != password.strip():
        return False, "Senha incorreta. Verifique suas credenciais."

    if not user_data.get("active", True):
        return False, "Sua conta foi suspensa ou bloqueada pelo administrador."

    exp_ts = float(user_data.get("expiration_timestamp", 0))
    now_ts = time.time()

    if now_ts >= exp_ts:
        exp_date_str = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y às %H:%M")
        return False, f"Sua licença EXPIROU em {exp_date_str}. Entre em contato para renovar."

    diff_sec = exp_ts - now_ts
    days = int(diff_sec // 86400)
    hours = int((diff_sec % 86400) // 3600)
    mins = int((diff_sec % 3600) // 60)

    time_left_str = []
    if days > 0: time_left_str.append(f"{days}d")
    if hours > 0: time_left_str.append(f"{hours}h")
    time_left_str.append(f"{mins}m")

    user_data["time_left_formatted"] = " ".join(time_left_str)
    user_data["expiration_formatted"] = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y %H:%M")
    user_data["balance"] = float(user_data.get("balance", 0.0))
    user_data["total_deposited"] = float(user_data.get("total_deposited", 0.0))
    user_data["total_withdrawn"] = float(user_data.get("total_withdrawn", 0.0))
    user_data["role"] = user_data.get("role", "user")  # "admin" ou "user"
    
    return True, user_data

def show_user_profile(username: str):
    """Exibe o perfil, saldo individual e estatísticas da conta do próprio usuário logado."""
    print_header("Meu Saldo & Perfil", "Dados da Sua Conta")
    
    username_clean = username.strip().lower()
    status, udata = _firebase_req(f"users/{username_clean}", method="GET")

    if status != 200 or not udata:
        print_status("Erro ao carregar dados do seu perfil.", "error")
        pause()
        return

    bal = float(udata.get("balance", 0.0))
    deposited = float(udata.get("total_deposited", 0.0))
    withdrawn = float(udata.get("total_withdrawn", 0.0))
    role_str = "ADMINISTRADOR MASTER" if udata.get("role") == "admin" else "CLIENTE"
    
    exp_ts = float(udata.get("expiration_timestamp", 0))
    now_ts = time.time()
    diff_sec = max(0, exp_ts - now_ts)
    days = int(diff_sec // 86400)
    hours = int((diff_sec % 86400) // 3600)
    mins = int((diff_sec % 3600) // 60)

    time_left_str = []
    if days > 0: time_left_str.append(f"{days}d")
    if hours > 0: time_left_str.append(f"{hours}h")
    time_left_str.append(f"{mins}m")
    
    exp_date_str = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y às %H:%M")
    is_active = udata.get("active", True) and (now_ts < exp_ts)

    content = (
        f"👤 Usuário:          {Colors.BOLD}{Colors.BRIGHT_WHITE}{username_clean}{Colors.RESET} ({role_str})\n"
        f"💰 Saldo Disponível: {Colors.BRIGHT_GREEN}{Colors.BOLD}R$ {bal:.2f}{Colors.RESET}\n"
        f"📥 Total Depositado: {Colors.BRIGHT_CYAN}R$ {deposited:.2f}{Colors.RESET}\n"
        f"📤 Total Sacado:     {Colors.BRIGHT_YELLOW}R$ {withdrawn:.2f}{Colors.RESET}\n"
        f"🏷️ Taxa Gateway:     {Colors.DIM}R$ 0,50 (Fixa por depósito){Colors.RESET}\n"
        f"{'─' * 45}\n"
        f"✔️ Status Licença:   {Colors.BRIGHT_GREEN if is_active else Colors.BRIGHT_RED}{'ATIVA / VÁLIDA' if is_active else 'EXPIRADA'}{Colors.RESET}\n"
        f"⏳ Tempo Restante:   {Colors.BRIGHT_GREEN}{' '.join(time_left_str)}{Colors.RESET}\n"
        f"📅 Data Expiração:   {exp_date_str}"
    )
    print_box(content, color=Colors.BRIGHT_GREEN, title=f"PERFIL DA CONTA: {username_clean.upper()}")
    pause()

def calculate_expiration(amount: int, unit: str) -> float:
    """Calcula timestamp de expiração."""
    now = datetime.now()
    if unit == "MINUTOS": dt = now + timedelta(minutes=amount)
    elif unit == "HORAS": dt = now + timedelta(hours=amount)
    elif unit == "DIAS": dt = now + timedelta(days=amount)
    elif unit == "SEMANAS": dt = now + timedelta(weeks=amount)
    elif unit == "MESES": dt = now + timedelta(days=amount * 30)
    else: dt = now + timedelta(days=amount)
    return dt.timestamp()

def register_user_in_firebase(username: str, password: str, duration_amount: int, duration_unit: str, role: str = "user") -> tuple:
    """Cria ou atualiza um usuário no Firebase com saldo individual e papel de acesso (role)."""
    username_clean = username.strip().lower()
    exp_ts = calculate_expiration(duration_amount, duration_unit.upper())
    exp_formatted = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y %H:%M:%S")

    # Busca se já existe para preservar saldo anterior
    _, existing = _firebase_req(f"users/{username_clean}", method="GET")
    existing_balance = float(existing.get("balance", 0.0)) if existing else 0.0
    existing_deposited = float(existing.get("total_deposited", 0.0)) if existing else 0.0
    existing_withdrawn = float(existing.get("total_withdrawn", 0.0)) if existing else 0.0

    user_payload = {
        "username": username_clean,
        "password": password.strip(),
        "role": role.strip().lower(),
        "balance": existing_balance,
        "total_deposited": existing_deposited,
        "total_withdrawn": existing_withdrawn,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "expiration_timestamp": exp_ts,
        "expiration_date": exp_formatted,
        "duration_amount": duration_amount,
        "duration_unit": duration_unit.upper(),
        "active": True
    }

    status, resp = _firebase_req(f"users/{username_clean}", method="PUT", data=user_payload)
    if status in (200, 201):
        return True, f"Usuário '{username_clean}' ({role.upper()}) criado/atualizado com sucesso!"
    return False, f"Erro no servidor (HTTP {status})."

def get_user_balance_from_firebase(username: str) -> float:
    """Obtém o saldo atualizado de um usuário no Firebase."""
    username_clean = username.strip().lower()
    status, bal = _firebase_req(f"users/{username_clean}/balance", method="GET")
    return float(bal) if status == 200 and bal is not None else 0.0

def credit_user_balance_in_firebase(username: str, gross_amount: float) -> tuple:
    """Credita o valor líquido (Valor Bruto - Taxa de Gateway R$ 0,50) no saldo do usuário no Firebase."""
    username_clean = username.strip().lower()
    net_amount = max(0.0, gross_amount - GATEWAY_FEE)

    status, udata = _firebase_req(f"users/{username_clean}", method="GET")
    if status != 200 or not udata:
        return False, "Usuário não encontrado.", 0.0

    current_bal = float(udata.get("balance", 0.0))
    current_dep = float(udata.get("total_deposited", 0.0))

    new_bal = current_bal + net_amount
    new_dep = current_dep + gross_amount

    _firebase_req(f"users/{username_clean}/balance", method="PUT", data=new_bal)
    _firebase_req(f"users/{username_clean}/total_deposited", method="PUT", data=new_dep)

    # Registra no histórico do usuário
    tx_entry = {
        "type": "DEPOSITO_PIX",
        "gross_amount": gross_amount,
        "fee": GATEWAY_FEE,
        "net_amount": net_amount,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    _firebase_req(f"user_transactions/{username_clean}", method="POST", data=tx_entry)

    return True, f"Creditado R$ {net_amount:.2f} (Taxa Gateway: R$ 0,50).", new_bal

def reserve_user_balance_for_withdrawal(username: str, amount: float) -> tuple:
    """Reserva (subtrai) o saldo do usuário para uma solicitação de saque, prevenindo saques duplos."""
    username_clean = username.strip().lower()
    status, udata = _firebase_req(f"users/{username_clean}", method="GET")
    if status != 200 or not udata:
        return False, "Usuário não encontrado.", 0.0

    current_bal = float(udata.get("balance", 0.0))
    if amount > current_bal:
        return False, f"Saldo insuficiente! Saldo atual: R$ {current_bal:.2f}", current_bal

    new_bal = current_bal - amount
    _firebase_req(f"users/{username_clean}/balance", method="PUT", data=new_bal)
    return True, "Saldo reservado com sucesso.", new_bal

def refund_user_balance_in_firebase(username: str, amount: float) -> float:
    """Reembolsa o saldo do usuário caso o saque seja recusado pelo administrador."""
    username_clean = username.strip().lower()
    status, udata = _firebase_req(f"users/{username_clean}", method="GET")
    current_bal = float(udata.get("balance", 0.0)) if status == 200 and udata else 0.0
    new_bal = current_bal + amount
    _firebase_req(f"users/{username_clean}/balance", method="PUT", data=new_bal)
    return new_bal

def get_all_users_from_firebase() -> list:
    """Retorna lista de todos os usuários cadastrados."""
    status, users_dict = _firebase_req("users", method="GET")
    if status != 200 or not users_dict:
        return []

    now_ts = time.time()
    result = []
    for uname, udata in users_dict.items():
        if isinstance(udata, dict):
            exp_ts = float(udata.get("expiration_timestamp", 0))
            is_active = udata.get("active", True) and (now_ts < exp_ts)
            
            diff_sec = max(0, exp_ts - now_ts)
            days = int(diff_sec // 86400)
            hours = int((diff_sec % 86400) // 3600)

            udata["status_label"] = "ATIVO" if is_active else "EXPIRADO"
            udata["remaining_str"] = f"{days}d {hours}h" if is_active else "Expirado"
            udata["balance"] = float(udata.get("balance", 0.0))
            udata["role"] = udata.get("role", "user")
            result.append(udata)
    return result

def toggle_user_status_in_firebase(username: str, active_state: bool) -> bool:
    username_clean = username.strip().lower()
    status, _ = _firebase_req(f"users/{username_clean}/active", method="PUT", data=active_state)
    return status == 200

def delete_user_from_firebase(username: str) -> bool:
    username_clean = username.strip().lower()
    status, _ = _firebase_req(f"users/{username_clean}", method="DELETE")
    return status == 200
