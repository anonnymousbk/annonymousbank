from core.ui import Colors, get_terminal_width

def get_anonymous_bank_banner() -> str:
    """Banner minimalista, executivo e responsivo para Annonymous Bank v5.0."""
    w = get_terminal_width()
    border = "═" * (w - 2)
    
    title = "⚡ ANONYMOUS BANK ⚡"
    subtitle = "SISTEMA FINANCEIRO PIX INTEGRADO v5.0"

    line_w = w - 2
    t_l = (line_w - len(title)) // 2
    t_r = line_w - len(title) - t_l
    
    s_l = (line_w - len(subtitle)) // 2
    s_r = line_w - len(subtitle) - s_l

    banner = (
        f"{Colors.BRIGHT_CYAN}╔{border}╗\n"
        f"║{' ' * t_l}{Colors.BOLD}{Colors.BRIGHT_WHITE}{title}{Colors.RESET}{Colors.BRIGHT_CYAN}{' ' * t_r}║\n"
        f"║{' ' * s_l}{Colors.BRIGHT_GREEN}{subtitle}{Colors.RESET}{Colors.BRIGHT_CYAN}{' ' * s_r}║\n"
        f"╚{border}╝{Colors.RESET}"
    )
    return banner
