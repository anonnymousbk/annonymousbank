from core.ui import Colors, get_terminal_width

def get_anonymous_bank_banner() -> str:
    """Banner compacto, responsivo e de alto padrão estético para Annonymous Bank."""
    w = get_terminal_width()
    line_w = w - 4
    
    title = "🏦 ANONYMOUS BANK"
    subtitle = "PIX FINANCIAL TERMINAL v3.0"
    
    t_pad_l = (line_w - len(title)) // 2
    t_pad_r = line_w - len(title) - t_pad_l
    
    s_pad_l = (line_w - len(subtitle)) // 2
    s_pad_r = line_w - len(subtitle) - s_pad_l

    banner = (
        f"{Colors.BRIGHT_GREEN}┌{'─' * (w - 2)}┐\n"
        f"│{' ' * t_pad_l}{Colors.BOLD}{Colors.BRIGHT_WHITE}{title}{Colors.RESET}{Colors.BRIGHT_GREEN}{' ' * t_pad_r}│\n"
        f"│{' ' * s_pad_l}{Colors.DIM}{Colors.BRIGHT_CYAN}{subtitle}{Colors.RESET}{Colors.BRIGHT_GREEN}{' ' * s_pad_r}│\n"
        f"└{'─' * (w - 2)}┘{Colors.RESET}"
    )
    return banner
