#!/usr/bin/env python3
import os
import sys
import json

# Suporte universal a UTF-8 no terminal
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, BASE_DIR)

from core.ui import Colors, clear_screen, print_header, print_status, print_box, prompt_input, pause
from core.banner import get_anonymous_bank_banner
from core.db import init_db
from core.notifier import send_native_notification
from modules.misticpay import MisticPayManager
from modules.transaction_history import run_history_menu

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

def load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "app_name": "Annonymous Bank PIX Terminal",
        "version": "5.0.0",
        "misticpay": {
            "api_base_url": "https://api.misticpay.com/api",
            "client_id": "",
            "client_secret": ""
        }
    }

def main():
    # Inicializa banco de dados SQLite interno
    init_db()

    config = load_config()
    mistic_mgr = MisticPayManager(config, CONFIG_FILE)

    while True:
        clear_screen()
        print(get_anonymous_bank_banner())
        
        is_cfg = mistic_mgr.is_configured()
        balance_str = "Consultando..."
        holder_str = ""
        verified_str = "CONECTADO"
        
        if is_cfg:
            try:
                status_code, data = mistic_mgr.fetch_user_info()
                if status_code == 200 and "data" in data:
                    u_info = data["data"]
                    bal = float(u_info.get("availableBalance", 0.0))
                    holder_str = u_info.get("name", "").strip()
                    balance_str = f"R$ {bal:.2f}"
                    if u_info.get("accountVerified"):
                        verified_str = "VERIFICADO"
                else:
                    balance_str = "Erro de Conexão"
                    verified_str = "FALHA DE REDE"
            except Exception:
                balance_str = "Erro de Conexão"
                verified_str = "DESCONECTADO"
        else:
            balance_str = "Não Configurado"
            verified_str = "PENDENTE"

        account_card = (
            f"👤 Titular: {Colors.BOLD}{Colors.BRIGHT_WHITE}{holder_str or 'Titular N/A'}{Colors.RESET}  │  Status: {Colors.BRIGHT_CYAN}{verified_str}{Colors.RESET}\n"
            f"💰 Saldo:   {Colors.BRIGHT_GREEN}{Colors.BOLD}{balance_str}{Colors.RESET}"
        )
        print_box(account_card, color=Colors.BRIGHT_GREEN, title="PAINEL EXECUTIVO")

        print(f"\n  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 📥 Cobrar via PIX (Gerar QR Code)")
        print(f"  [{Colors.BRIGHT_CYAN}2{Colors.RESET}] 📤 Transferir / Sacar PIX")
        print(f"  [{Colors.BRIGHT_MAGENTA}3{Colors.RESET}] 📊 Extrato & Histórico de Transações")
        print(f"  [{Colors.BRIGHT_YELLOW}4{Colors.RESET}] 👤 Saldo & Perfil Detalhado")
        print(f"  [{Colors.BRIGHT_BLUE}5{Colors.RESET}] ⏱️  Monitorar Transação por ID")
        print(f"  [{Colors.BRIGHT_WHITE}6{Colors.RESET}] ⚙️  Credenciais da API")
        print(f"  [{Colors.BRIGHT_YELLOW}7{Colors.RESET}] 🔔 Testar Notificação Push Android")
        print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] 🚪 Sair")

        choice = prompt_input("\nOpção", default="1")

        if choice == "0":
            print(f"\n{Colors.BRIGHT_CYAN}Saindo do Anonymous Bank v5.0. Até logo!{Colors.RESET}\n")
            sys.exit(0)
        elif choice == "1":
            mistic_mgr.generate_pix()
        elif choice == "2":
            mistic_mgr.send_pix()
        elif choice == "3":
            run_history_menu(mistic_mgr)
        elif choice == "4":
            mistic_mgr.show_account_info()
        elif choice == "5":
            tx_id = prompt_input("Informe o ID da transação a monitorar")
            if tx_id:
                mistic_mgr.monitor_transaction(tx_id)
        elif choice == "6":
            mistic_mgr.configure_credentials()
            config = load_config()
            mistic_mgr = MisticPayManager(config, CONFIG_FILE)
        elif choice == "7":
            print_header("Testar Notificação Push no Android")
            send_native_notification("🔔 Annonymous Bank v5.0", "Notificações push e vibração ativas!")
            print_status("Notificação de teste disparada com sucesso!", "success")
            print_status("Verifique a barra de notificações do seu celular.", "info")
            pause()
        else:
            print_status("Opção inválida.", "error")

if __name__ == "__main__":
    main()
