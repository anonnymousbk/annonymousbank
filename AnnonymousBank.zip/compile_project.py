#!/usr/bin/env python3
import os
import sys
import shutil
import compileall

# Garante suporte a UTF-8 no stdout
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
DIST_DIR = os.path.join(BASE_DIR, "dist_protected")

def build_compiled_distribution():
    """Gera a versão compilada e protegida nativamente para a versão do Python em execução.
    Converte todo o código Python em Bytecode binário (.pyc) com a Magic Number exata do sistema.
    """
    print("====================================================")
    print(f"   COMPILADOR DE BYTECODE PROTEGIDO v6.5 (Python {sys.version.split()[0]})   ")
    print("====================================================")
    print("\n[1/3] Preparando estrutura de compilação protegida...")

    if os.path.exists(DIST_DIR):
        try:
            shutil.rmtree(DIST_DIR)
        except Exception:
            pass

    os.makedirs(DIST_DIR, exist_ok=True)

    # Copia todo o projeto para a pasta de distribuição
    shutil.copytree(BASE_DIR, DIST_DIR, dirs_exist_ok=True, ignore=shutil.ignore_patterns("dist_protected", "*.pyc", "__pycache__", ".git"))

    print(f"[2/3] Compilando arquivos Python (.py) para Bytecode (.pyc) nativo do Python {sys.version.split()[0]}...")
    compileall.compile_dir(DIST_DIR, force=True, legacy=True)

    print("[3/3] Removendo código-fonte (.py) para proteção contra engenharia reversa...")
    removed_count = 0
    for root, dirs, files in os.walk(DIST_DIR):
        for f in files:
            if f.endswith(".py") and f not in ("install.sh",):
                py_file = os.path.join(root, f)
                try:
                    os.remove(py_file)
                    removed_count += 1
                except Exception:
                    pass

    print("\n====================================================")
    print(" [OK] COMPILACAO E PROTECAO CONCLUIDAS COM SUCESSO!")
    print("====================================================")
    print(f"Foram compilados {removed_count} arquivos Python com a Magic Number nativa do Python {sys.version.split()[0]}.")
    print(f"Pasta gerada: {DIST_DIR}")
    print("\nPara distribuir aos clientes, envie o conteúdo da pasta 'dist_protected'.")
    print("O cliente poderá executar normalmente no Termux digitando: anon  ou  python main.pyc")
    print("====================================================")

if __name__ == "__main__":
    build_compiled_distribution()
