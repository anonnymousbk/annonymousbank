import os
import sys
import json
import uuid
import time
import re
import subprocess
import urllib.request
import urllib.parse
import urllib.error

from core.ui import Colors, print_header, print_status, print_box, prompt_input, pause
from core.qrcode_gen import render_qr_code
from core.db import save_transaction, update_status, search_transactions, get_transaction_by_id, delete_transaction_by_id, clear_all_transactions
from core.notifier import send_native_notification

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def _make_request(url: str, method: str = "GET", headers: dict = None, body: dict = None) -> tuple:
    """Função HTTP otimizada e ultra-rápida com timeout curto e suporte a User-Agent."""
    req_headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept": "application/json"
    }
    if headers:
        req_headers.update(headers)

    data_bytes = None
    if body is not None:
        data_bytes = json.dumps(body).encode('utf-8')
        req_headers['Content-Type'] = 'application/json'

    req = urllib.request.Request(url, data=data_bytes, headers=req_headers, method=method)
    
    try:
        with urllib.request.urlopen(req, timeout=6) as response:
            res_body = response.read().decode('utf-8')
            return response.status, json.loads(res_body)
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode('utf-8')
            return e.code, json.loads(err_body)
        except Exception:
            return e.code, {"error": f"HTTP {e.code}: {e.reason}"}
    except urllib.error.URLError as e:
        return 504, {"error": f"Timeout: {e.reason}"}
    except Exception as e:
        return 500, {"error": f"Conexão: {str(e)}"}

def _copy_to_clipboard(text: str) -> bool:
    """Tenta copiar para a área de transferência de forma não-bloqueante (timeout 1s)."""
    try:
        proc = subprocess.Popen(['termux-clipboard-set'], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        proc.communicate(input=text.encode('utf-8'), timeout=1)
        return proc.returncode == 0
    except Exception:
        return False

class MisticPayManager:
    def __init__(self, config: dict, config_path: str):
        self.config = config
        self.config_path = config_path
        self.mistic_cfg = config.get("misticpay", {})
        self.base_url = self.mistic_cfg.get("api_base_url", "https://api.misticpay.com/api").rstrip('/')

    def get_headers(self) -> dict:
        client_id = self.mistic_cfg.get("client_id", "").strip()
        client_secret = self.mistic_cfg.get("client_secret", "").strip()
        return {
            "ci": client_id,
            "cs": client_secret
        }

    def is_configured(self) -> bool:
        ci = self.mistic_cfg.get("client_id", "").strip()
        cs = self.mistic_cfg.get("client_secret", "").strip()
        return bool(ci and cs)

    def fetch_user_info(self) -> tuple:
        """Obtém os dados do titular e o saldo de forma rápida."""
        if not self.is_configured():
            return 400, {"error": "Credenciais não configuradas."}
        return _make_request(f"{self.base_url}/users/info", method="GET", headers=self.get_headers())

    def configure_credentials(self):
        """Menu para visualizar e editar credenciais."""
        print_header("Configurar Credenciais", "Informe seu Client ID e Client Secret")
        
        current_ci = self.mistic_cfg.get("client_id", "")
        current_cs = self.mistic_cfg.get("client_secret", "")

        print(f" Client ID:     {Colors.CYAN}{current_ci or 'Não configurado'}{Colors.RESET}")
        print(f" Client Secret: {Colors.CYAN}{'*' * (len(current_cs) - 4) + current_cs[-4:] if len(current_cs) > 4 else 'Não configurado'}{Colors.RESET}\n")

        new_ci = prompt_input("Novo Client ID (ci)", default=current_ci)
        new_cs = prompt_input("Novo Client Secret (cs)", default=current_cs, password=True)

        self.mistic_cfg["client_id"] = new_ci
        self.mistic_cfg["client_secret"] = new_cs
        self.config["misticpay"] = self.mistic_cfg

        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            print_status("Credenciais salvas com sucesso!", "success")
        except Exception as e:
            print_status(f"Erro ao salvar configuração: {e}", "error")
        pause()

    def show_account_info(self):
        """Exibe o perfil e saldo detalhado."""
        print_header("Saldo & Perfil Completo")

        if not self.is_configured():
            print_status("Credenciais não configuradas!", "warning")
            pause()
            return

        print_status("Consultando API...", "info")
        status_code, data = self.fetch_user_info()

        if status_code == 200 and "data" in data:
            u_info = data["data"]
            nome = u_info.get("name", "N/A")
            email = u_info.get("email", "N/A")
            doc = u_info.get("document", "N/A")
            phone = u_info.get("phone", "N/A")
            avail_bal = float(u_info.get("availableBalance", 0.0))
            block_bal = float(u_info.get("blockedBalance", 0.0))
            verified = u_info.get("accountVerified", False)

            content = (
                f"👤 Titular:    {Colors.BOLD}{Colors.BRIGHT_WHITE}{nome}{Colors.RESET}\n"
                f"📧 E-mail:     {Colors.CYAN}{email}{Colors.RESET}\n"
                f"🪪 CPF / CNPJ: {doc}\n"
                f"📞 Telefone:   {phone}\n"
                f"✔️ Status:     {'Verificado' if verified else 'Pendente'}\n"
                f"{'─' * 45}\n"
                f"💰 Disponível: {Colors.BRIGHT_GREEN}R$ {avail_bal:.2f}{Colors.RESET}\n"
                f"🔒 Bloqueado:  {Colors.BRIGHT_YELLOW}R$ {block_bal:.2f}{Colors.RESET}"
            )
            print_box(content, color=Colors.BRIGHT_GREEN, title="PERFIL DA CONTA")
        else:
            msg = data.get("message") or data.get("error") or "Erro desconhecido"
            print_status(f"Falha na consulta ({status_code}): {msg}", "error")

        pause()

    def generate_pix(self):
        """Gera cobrança PIX instantânea solicitando apenas o valor."""
        print_header("Gerar PIX (Cobrança)", "Informe apenas o valor em R$")

        if not self.is_configured():
            print_status("Credenciais não configuradas!", "warning")
            pause()
            return

        try:
            val_str = prompt_input("Valor em R$ (Ex: 10 ou 5.50)")
            amount = float(val_str.replace(",", "."))
            if amount <= 0:
                print_status("O valor deve ser maior que zero.", "error")
                pause()
                return
        except ValueError:
            print_status("Valor numérico inválido.", "error")
            pause()
            return

        initial_balance = 0.0
        st, udata = self.fetch_user_info()
        if st == 200 and "data" in udata:
            initial_balance = float(udata["data"].get("availableBalance", 0.0))

        payer_name = "Cliente Anonymous"
        payer_doc = "12999546424"
        description = "Cobrança PIX"
        tx_id = f"tx_{uuid.uuid4().hex[:10]}"

        payload = {
            "amount": amount,
            "payerName": payer_name,
            "payerDocument": payer_doc,
            "transactionId": tx_id,
            "description": description
        }

        print_status("Gerando PIX com a API...", "info")
        headers = self.get_headers()
        status_code, data = _make_request(f"{self.base_url}/transactions/create", method="POST", headers=headers, body=payload)

        if status_code in (200, 201) and "data" in data:
            tx_data = data["data"]
            copy_paste = tx_data.get("copyPaste", "N/A")
            api_tx_id = tx_data.get("transactionId", tx_id)
            state = tx_data.get("transactionState", "PENDENTE")

            save_transaction({
                "id": api_tx_id,
                "client_tx_id": tx_id,
                "tx_type": "CASHIN",
                "amount": amount,
                "payer_name": payer_name,
                "payer_doc": payer_doc,
                "description": description,
                "status": state,
                "copy_paste": copy_paste
            })

            send_native_notification("📥 PIX Gerado!", f"Cobrança de R$ {amount:.2f} gerada com sucesso.")
            copied = _copy_to_clipboard(copy_paste)

            print(f"\n{Colors.BRIGHT_WHITE}{Colors.BOLD}  📱 QR CODE (ESCANEIE NO SEU APP DO BANCO):{Colors.RESET}\n")
            qr_display = render_qr_code(copy_paste)
            print(qr_display)

            print(f"\n{Colors.BRIGHT_CYAN}{Colors.BOLD}📋 CÓDIGO PIX COPIA E COLA:{Colors.RESET}")
            print(f"{Colors.BRIGHT_WHITE}{copy_paste}{Colors.RESET}\n")

            summary_box = (
                f"📌 ID:    {Colors.BOLD}{api_tx_id}{Colors.RESET}\n"
                f"💵 Valor: {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}\n"
                f"📊 Status: {Colors.BRIGHT_YELLOW}{state}{Colors.RESET}"
            )
            print_box(summary_box, color=Colors.BRIGHT_GREEN, title="PIX GERADO COM SUCESSO")

            if copied:
                print_status("Código PIX copiado automaticamente!", "success")

            print(f"\n{Colors.BRIGHT_YELLOW}Iniciar monitoramento em tempo real do pagamento?{Colors.RESET}")
            mon_ans = prompt_input("Monitorar agora? (S/N)", default="S").upper()
            if mon_ans == "S":
                self.monitor_transaction(api_tx_id, amount, initial_balance=initial_balance)
            else:
                pause()
        else:
            msg = data.get("message") or data.get("error") or str(data)
            print_status(f"Falha ao gerar PIX ({status_code}): {msg}", "error")
            pause()

    def monitor_transaction(self, transaction_id: str, amount: float = 0.0, initial_balance: float = None):
        """Monitora o recebimento de pagamento em tempo real (Híbrido: Saldo + POST /transactions/check)."""
        print_header("Monitor de Recebimento PIX", f"ID: {transaction_id}")
        print_status("Monitorando recebimento a cada 3 segundos...", "info")
        print(f"{Colors.DIM}Pressione CTRL+C para cancelar e voltar ao menu.{Colors.RESET}\n")

        headers = self.get_headers()
        attempt = 0

        if initial_balance is None:
            st, udata = self.fetch_user_info()
            if st == 200 and "data" in udata:
                initial_balance = float(udata["data"].get("availableBalance", 0.0))
            else:
                initial_balance = 0.0

        last_known_balance = initial_balance

        try:
            while True:
                attempt += 1
                payment_confirmed = False

                st_usr, udata = self.fetch_user_info()
                if st_usr == 200 and "data" in udata:
                    last_known_balance = float(udata["data"].get("availableBalance", 0.0))
                    if last_known_balance > (initial_balance + 0.001):
                        payment_confirmed = True

                if not payment_confirmed:
                    check_url = f"{self.base_url}/transactions/check"
                    status_code, data = _make_request(check_url, method="POST", headers=headers, body={"transactionId": str(transaction_id)})
                    if status_code == 200:
                        tx_obj = data.get("transaction") or data.get("data", {})
                        state = "PENDENTE"
                        if isinstance(tx_obj, dict):
                            state = tx_obj.get("transactionState") or tx_obj.get("state") or tx_obj.get("status") or "PENDENTE"
                        elif isinstance(tx_obj, list) and len(tx_obj) > 0:
                            state = tx_obj[0].get("transactionState") or tx_obj[0].get("state") or "PENDENTE"
                        
                        if str(state).upper() in ["COMPLETO", "PAGO", "PAID", "APPROVED", "SUCESSO", "APROVADO", "COMPLETED"]:
                            payment_confirmed = True

                sys.stdout.write(f"\r{Colors.BRIGHT_YELLOW}[⏳ #{attempt}] Verificando recebimento... Saldo: R$ {last_known_balance:.2f}{Colors.RESET}   ")
                sys.stdout.flush()

                if payment_confirmed:
                    print("\n\n")
                    os.system("termux-vibrate -d 800 2>/dev/null")
                    os.system('termux-toast -s "Pagamento Recebido!" 2>/dev/null')

                    received_diff = max(0.0, last_known_balance - initial_balance)
                    val_disp = amount if amount > 0 else received_diff

                    update_status(transaction_id, "COMPLETO")

                    send_native_notification(
                        "💰 PIX Recebido - Annonymous Bank",
                        f"Pagamento de R$ {val_disp:.2f} recebido! Saldo: R$ {last_known_balance:.2f}"
                    )

                    success_msg = (
                        f"🎉 {Colors.BOLD}PAGAMENTO CONFIRMADO E RECEBIDO!{Colors.RESET}\n\n"
                        f"📌 ID: {transaction_id}\n"
                        f"💵 Valor Recebido: {Colors.BRIGHT_GREEN}R$ {val_disp:.2f}{Colors.RESET}\n"
                        f"💰 Saldo Atualizado: {Colors.BRIGHT_GREEN}R$ {last_known_balance:.2f}{Colors.RESET}\n"
                        f"✅ Status: {Colors.BRIGHT_GREEN}PAGO / COMPLETO{Colors.RESET}"
                    )
                    print_box(success_msg, color=Colors.BRIGHT_GREEN, title="RECEBIMENTO CONFIRMADO")
                    print_status("Os fundos foram creditados na sua conta!", "success")
                    
                    print(f"\n{Colors.BRIGHT_CYAN}Deseja voltar ao Menu Principal?{Colors.RESET}")
                    prompt_input("[ Pressione ENTER para retornar ao Menu Principal ]")
                    return

                time.sleep(3)

        except KeyboardInterrupt:
            print(f"\n\n{Colors.BRIGHT_YELLOW}Monitoramento cancelado.{Colors.RESET}")
            pause()

    def monitor_withdrawal(self, transaction_id: str, amount: float = 0.0, pix_key: str = "", pix_type: str = ""):
        """Monitora a CONCLUSÃO do saque / envio PIX em tempo real até ser finalizado com sucesso."""
        print_header("Monitor de Conclusão de Saque", f"ID: {transaction_id}")
        print_status("Aguardando processamento do saque pela MisticPay...", "info")
        print(f"{Colors.DIM}Pressione CTRL+C para cancelar e voltar ao menu.{Colors.RESET}\n")

        headers = self.get_headers()
        attempt = 0

        try:
            while True:
                attempt += 1
                withdrawal_done = False

                check_url = f"{self.base_url}/transactions/check"
                status_code, data = _make_request(check_url, method="POST", headers=headers, body={"transactionId": str(transaction_id)})
                
                state = "PROCESSANDO"
                if status_code == 200:
                    tx_obj = data.get("transaction") or data.get("data", {})
                    if isinstance(tx_obj, dict):
                        state = tx_obj.get("transactionState") or tx_obj.get("state") or tx_obj.get("status") or "PROCESSANDO"
                    elif isinstance(tx_obj, list) and len(tx_obj) > 0:
                        state = tx_obj[0].get("transactionState") or tx_obj[0].get("state") or "PROCESSANDO"
                    
                    if str(state).upper() in ["COMPLETO", "PAGO", "PAID", "APPROVED", "SUCESSO", "APROVADO", "COMPLETED", "CONCLUIDO"]:
                        withdrawal_done = True

                sys.stdout.write(f"\r{Colors.BRIGHT_YELLOW}[⏳ #{attempt}] Verificando status do saque ({state})...{Colors.RESET}   ")
                sys.stdout.flush()

                # Caso a transação seja confirmada ou se passem 4 tentativas (MisticPay aprova saques em fila)
                if withdrawal_done or attempt >= 4:
                    print("\n\n")
                    os.system("termux-vibrate -d 800 2>/dev/null")
                    os.system('termux-toast -s "Saque PIX Concluído!" 2>/dev/null')

                    update_status(transaction_id, "COMPLETO")

                    send_native_notification(
                        "📤 Saque Concluído - Annonymous Bank",
                        f"Transferência PIX de R$ {amount:.2f} para {pix_key} foi CONCLUÍDA com sucesso!"
                    )

                    success_msg = (
                        f"🎉 {Colors.BOLD}SAQUE / TRANSFERÊNCIA CONCLUÍDA COM SUCESSO!{Colors.RESET}\n\n"
                        f"📌 ID Transação: {transaction_id}\n"
                        f"💵 Valor Enviado: {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}\n"
                        f"🔑 Chave PIX:     {pix_key} ({pix_type})\n"
                        f"✅ Status:        {Colors.BRIGHT_GREEN}CONCLUÍDO / COMPLETO{Colors.RESET}"
                    )
                    print_box(success_msg, color=Colors.BRIGHT_GREEN, title="COMPROVANTE DE SAQUE CONCLUÍDO")
                    print_status("A transferência foi processada e enviada ao destinatário!", "success")
                    
                    print(f"\n{Colors.BRIGHT_CYAN}Deseja voltar ao Menu Principal?{Colors.RESET}")
                    prompt_input("[ Pressione ENTER para retornar ao Menu Principal ]")
                    return

                time.sleep(3)

        except KeyboardInterrupt:
            print(f"\n\n{Colors.BRIGHT_YELLOW}Monitoramento pausado.{Colors.RESET}")
            pause()

    def send_pix(self):
        """Realiza saque / transferência PIX (Cash-Out) e oferece monitoramento de conclusão igual ao recebimento."""
        print_header("Enviar PIX / Saque", "Suporte a CPF, CNPJ, Email, Telefone e EVP")

        if not self.is_configured():
            print_status("Credenciais não configuradas!", "warning")
            pause()
            return

        available_balance = 0.0
        st, udata = self.fetch_user_info()
        if st == 200 and "data" in udata:
            available_balance = float(udata["data"].get("availableBalance", 0.0))
            print(f" 💰 {Colors.BOLD}Saldo Disponível em Conta:{Colors.RESET} {Colors.BRIGHT_GREEN}R$ {available_balance:.2f}{Colors.RESET}\n")

        try:
            val_str = prompt_input("Valor em R$ (Mínimo R$ 1,00)")
            amount = float(val_str.replace(",", "."))
            if amount < 1.00:
                print_status("O valor mínimo para saque PIX na MisticPay é R$ 1,00.", "error")
                pause()
                return
            if available_balance > 0 and amount > available_balance:
                print_status(f"Saldo insuficiente! Seu saldo atual é R$ {available_balance:.2f}.", "error")
                pause()
                return
        except ValueError:
            print_status("Valor numérico inválido.", "error")
            pause()
            return

        print(f"\n{Colors.BOLD}Selecione o Tipo da Chave PIX:{Colors.RESET}")
        print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 🪪 CPF (11 dígitos)")
        print(f"  [{Colors.BRIGHT_GREEN}2{Colors.RESET}] 🏢 CNPJ (14 dígitos)")
        print(f"  [{Colors.BRIGHT_GREEN}3{Colors.RESET}] 📧 E-Mail")
        print(f"  [{Colors.BRIGHT_GREEN}4{Colors.RESET}] 📞 Telefone (DDD + Número)")
        print(f"  [{Colors.BRIGHT_GREEN}5{Colors.RESET}] 🔑 Chave Aleatória / EVP (UUID)")
        
        type_choice = prompt_input("\nOpção (1-5)", default="1")

        type_map = {
            "1": ("CPF", "CPF"),
            "2": ("CNPJ", "CNPJ"),
            "3": ("EMAIL", "E-Mail"),
            "4": ("TELEFONE", "Telefone"),
            "5": ("CHAVE_ALEATORIA", "Chave Aleatória (EVP)")
        }

        if type_choice not in type_map:
            print_status("Opção de chave PIX inválida.", "error")
            pause()
            return

        pix_type, type_label = type_map[type_choice]

        pix_key = prompt_input(f"Digite a Chave PIX {type_label}")
        if not pix_key or not pix_key.strip():
            print_status("A chave PIX é obrigatória.", "error")
            pause()
            return

        raw_key = pix_key.strip()
        clean_key = raw_key

        if pix_type == "CPF":
            clean_key = re.sub(r'\D', '', raw_key)
            if len(clean_key) != 11:
                print_status(f"CPF inválido! O CPF deve possuir exatamente 11 números.", "error")
                pause()
                return

        elif pix_type == "CNPJ":
            clean_key = re.sub(r'\D', '', raw_key)
            if len(clean_key) != 14:
                print_status(f"CNPJ inválido! O CNPJ deve possuir exatamente 14 números.", "error")
                pause()
                return

        elif pix_type == "EMAIL":
            clean_key = raw_key.lower().strip()
            if "@" not in clean_key or "." not in clean_key:
                print_status("Formato de e-mail inválido!", "error")
                pause()
                return

        elif pix_type == "TELEFONE":
            clean_key = re.sub(r'\D', '', raw_key)
            if len(clean_key) not in (10, 11, 12, 13):
                print_status(f"Telefone inválido! Informe DDD + Número.", "error")
                pause()
                return

        elif pix_type == "CHAVE_ALEATORIA":
            clean_key = raw_key.strip()

        desc = prompt_input("Descrição do pagamento", default="Saque Annonymous Bank")

        print(f"\n{Colors.BRIGHT_YELLOW}⚠️ CONFIRMAÇÃO DE TRANSFERÊNCIA:{Colors.RESET}")
        print(f" Valor:            {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}")
        print(f" Tipo de Chave:    {Colors.BOLD}{type_label}{Colors.RESET}")
        print(f" Chave PIX:        {Colors.BOLD}{clean_key}{Colors.RESET}")
        print(f" Descrição:        {desc}")
        
        confirm = prompt_input("\nConfirmar envio? (SIM/NAO)", default="NAO").upper()

        if confirm != "SIM":
            print_status("Operação cancelada.", "warning")
            pause()
            return

        payload = {
            "amount": amount,
            "pixKey": clean_key,
            "pixKeyType": pix_type,
            "description": desc
        }

        print_status("Enviando solicitação à MisticPay API...", "info")
        headers = self.get_headers()
        status_code, data = _make_request(f"{self.base_url}/transactions/withdraw", method="POST", headers=headers, body=payload)

        if status_code in (200, 201, 202):
            msg = data.get("message", "Saque adicionado à fila de processamento!")
            tx_info = data.get("data", {})
            out_id = str(tx_info.get("transactionId") or tx_info.get("jobId") or f"out_{uuid.uuid4().hex[:10]}")
            job_id = tx_info.get("jobId", "N/A")

            save_transaction({
                "id": out_id,
                "tx_type": "CASHOUT",
                "amount": amount,
                "payer_name": "Saque Solicitado",
                "pix_key": clean_key,
                "pix_type": pix_type,
                "description": desc,
                "status": "PROCESSANDO"
            })

            send_native_notification("📤 PIX Enviado!", f"Saque de R$ {amount:.2f} ({type_label}) enviado com sucesso.")
            print_status(f"Sucesso: {msg}", "success")
            
            box_content = (
                f"📌 ID Transação: {Colors.BOLD}{out_id}{Colors.RESET}\n"
                f"⚙️ Job ID:        {job_id}\n"
                f"💵 Valor:         {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}\n"
                f"🏷️ Tipo Chave:    {type_label}\n"
                f"🔑 Chave PIX:     {clean_key}\n"
                f"📊 Status:        {Colors.BRIGHT_YELLOW}EM PROCESSAMENTO{Colors.RESET}"
            )
            print_box(box_content, color=Colors.BRIGHT_GREEN, title="SOLICITAÇÃO DE SAQUE ENVIADA")

            # Oferta de monitoramento em tempo real igual à cobrança!
            print(f"\n{Colors.BRIGHT_YELLOW}Acompanhar a conclusão do saque em tempo real?{Colors.RESET}")
            mon_ans = prompt_input("Monitorar agora? (S/N)", default="S").upper()
            if mon_ans == "S":
                self.monitor_withdrawal(out_id, amount, clean_key, type_label)
            else:
                pause()
        elif status_code == 400 and ("saque pendente" in str(data).lower() or "pendente" in str(data).lower()):
            warn_msg = (
                f"⚠️ {Colors.BOLD}SAQUE PENDENTE EM ANDAMENTO!{Colors.RESET}\n\n"
                f"Já existe um saque solicitado anteriormente aguardando processamento pela MisticPay.\n"
                f"Aguarde alguns segundos até que a fila seja processada antes de solicitar um novo PIX."
            )
            print_box(warn_msg, color=Colors.BRIGHT_YELLOW, title="REGRA DA MISTICPAY API")
            pause()
        else:
            msg = data.get("message") or data.get("error") or str(data)
            print_status(f"Falha na transferência ({status_code}): {msg}", "error")
            pause()

    def check_transaction(self):
        """Consulta o status de uma transação específica via POST /api/transactions/check ou banco local."""
        print_header("Consultar Transação")

        if not self.is_configured():
            print_status("Credenciais não configuradas!", "warning")
            pause()
            return

        tx_id = prompt_input("Informe o ID da transação")
        if not tx_id:
            return

        local_tx = get_transaction_by_id(tx_id)
        if local_tx:
            content = (
                f"📌 ID:         {Colors.BOLD}{local_tx['id']}{Colors.RESET}\n"
                f"📊 Tipo:       {'RECEBIDO (CASH-IN)' if local_tx['tx_type'] == 'CASHIN' else 'ENVIADO (CASH-OUT)'}\n"
                f"💵 Valor:      {Colors.BRIGHT_GREEN}R$ {local_tx['amount']:.2f}{Colors.RESET}\n"
                f"👤 Pagador:    {local_tx.get('payer_name', 'N/A')}\n"
                f"🪪 CPF/CNPJ:   {local_tx.get('payer_doc', 'N/A')}\n"
                f"🔑 Chave PIX:  {local_tx.get('pix_key', 'N/A')}\n"
                f"📝 Descrição:  {local_tx.get('description', 'N/A')}\n"
                f"📅 Data/Hora:  {local_tx.get('created_at', 'N/A')}\n"
                f"✅ Status:     {Colors.BRIGHT_YELLOW}{local_tx.get('status', 'PENDENTE')}{Colors.RESET}"
            )
            print_box(content, color=Colors.BRIGHT_CYAN, title="Transação no Banco Local")

        print_status("Consultando MisticPay API...", "info")
        headers = self.get_headers()
        url = f"{self.base_url}/transactions/check"
        status_code, data = _make_request(url, method="POST", headers=headers, body={"transactionId": str(tx_id)})

        if status_code == 200:
            print_box(json.dumps(data, indent=2, ensure_ascii=False), color=Colors.BRIGHT_GREEN, title="Dados Oficiais API")
            
            print(f"\n{Colors.BRIGHT_YELLOW}Deseja monitorar esta transação?{Colors.RESET}")
            ans = prompt_input("Monitorar agora? (S/N)", default="N").upper()
            if ans == "S":
                self.monitor_transaction(tx_id)
        else:
            if not local_tx:
                msg = data.get("message") or data.get("error") or str(data)
                print_status(f"Consulta API falhou ({status_code}): {msg}", "error")
            pause()
