import os
import sys
import json
import uuid
import time
import re
import subprocess
import urllib.request
import urllib.parse
import urllib.error

from core.ui import Colors, print_header, print_status, print_box, prompt_input, pause
from core.qrcode_gen import render_qr_code
from core.db import save_transaction, update_status, search_transactions, get_transaction_by_id, delete_transaction_by_id, clear_all_transactions
from core.auth import (
    credit_user_balance_in_firebase,
    get_user_balance_from_firebase,
    get_cloud_gateway_config,
    save_cloud_gateway_config,
    GATEWAY_FEE
)
from core.withdrawals import create_withdrawal_request
from core.notifier import send_native_notification

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def _make_request(url: str, method: str = "GET", headers: dict = None, body: dict = None) -> tuple:
    """Função HTTP otimizada e ultra-rápida com timeout curto e suporte a User-Agent."""
    req_headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept": "application/json"
    }
    if headers:
        req_headers.update(headers)

    data_bytes = None
    if body is not None:
        data_bytes = json.dumps(body).encode('utf-8')
        req_headers['Content-Type'] = 'application/json'

    req = urllib.request.Request(url, data=data_bytes, headers=req_headers, method=method)
    
    try:
        with urllib.request.urlopen(req, timeout=6) as response:
            res_body = response.read().decode('utf-8')
            return response.status, json.loads(res_body)
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode('utf-8')
            return e.code, json.loads(err_body)
        except Exception:
            return e.code, {"error": f"HTTP {e.code}: {e.reason}"}
    except urllib.error.URLError as e:
        return 504, {"error": f"Timeout: {e.reason}"}
    except Exception as e:
        return 500, {"error": f"Conexão: {str(e)}"}

def _copy_to_clipboard(text: str) -> bool:
    """Tenta copiar para a área de transferência de forma não-bloqueante (timeout 1s)."""
    try:
        proc = subprocess.Popen(['termux-clipboard-set'], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        proc.communicate(input=text.encode('utf-8'), timeout=1)
        return proc.returncode == 0
    except Exception:
        return False

class MisticPayManager:
    def __init__(self, config: dict = None, config_path: str = None):
        self.config = config or {}
        self.config_path = config_path

    @property
    def cloud_cfg(self) -> dict:
        """Busca credenciais online armazenadas com segurança no servidor."""
        return get_cloud_gateway_config()

    @property
    def base_url(self) -> str:
        return self.cloud_cfg.get("api_base_url", "https://api.misticpay.com/api").rstrip('/')

    def _make_request_raw(self, url: str, method: str = "GET", headers: dict = None, body: dict = None) -> tuple:
        return _make_request(url, method=method, headers=headers, body=body)

    def get_headers(self) -> dict:
        cfg = self.cloud_cfg
        return {
            "ci": cfg.get("client_id", "").strip(),
            "cs": cfg.get("client_secret", "").strip()
        }

    def is_configured(self) -> bool:
        cfg = self.cloud_cfg
        return bool(cfg.get("client_id") and cfg.get("client_secret"))

    def fetch_user_info(self) -> tuple:
        """Obtém os dados do titular e o saldo de forma rápida."""
        if not self.is_configured():
            return 400, {"error": "Credenciais não configuradas no servidor."}
        return _make_request(f"{self.base_url}/users/info", method="GET", headers=self.get_headers())

    def configure_credentials(self):
        """Menu para visualizar e editar credenciais salvas no servidor online (Exclusivo Admin)."""
        print_header("Configurar Credenciais do Servidor", "Apenas Administrador Master")
        
        cfg = self.cloud_cfg
        current_ci = cfg.get("client_id", "")
        current_cs = cfg.get("client_secret", "")

        print(f" Client ID:     {Colors.CYAN}{current_ci or 'Não configurado'}{Colors.RESET}")
        print(f" Client Secret: {Colors.CYAN}{'*' * (len(current_cs) - 4) + current_cs[-4:] if len(current_cs) > 4 else 'Não configurado'}{Colors.RESET}\n")

        new_ci = prompt_input("Novo Client ID (ci)", default=current_ci)
        new_cs = prompt_input("Novo Client Secret (cs)", default=current_cs, password=True)

        print_status("Gravando credenciais no servidor online seguro...", "info")
        ok = save_cloud_gateway_config(new_ci, new_cs)

        if ok:
            print_status("Credenciais salvas online no servidor com sucesso!", "success")
        else:
            print_status("Erro ao salvar credenciais no servidor.", "error")
        pause()

    def show_account_info(self):
        """Exibe o perfil e saldo detalhado da API Gateway."""
        print_header("Saldo & Perfil Completo da API")

        if not self.is_configured():
            print_status("Credenciais não configuradas no servidor!", "warning")
            pause()
            return

        print_status("Consultando Servidor...", "info")
        status_code, data = self.fetch_user_info()

        if status_code == 200 and "data" in data:
            u_info = data["data"]
            nome = u_info.get("name", "N/A")
            email = u_info.get("email", "N/A")
            doc = u_info.get("document", "N/A")
            phone = u_info.get("phone", "N/A")
            avail_bal = float(u_info.get("availableBalance", 0.0))
            block_bal = float(u_info.get("blockedBalance", 0.0))
            verified = u_info.get("accountVerified", False)

            content = (
                f"👤 Titular:    {Colors.BOLD}{Colors.BRIGHT_WHITE}{nome}{Colors.RESET}\n"
                f"📧 E-mail:     {Colors.CYAN}{email}{Colors.RESET}\n"
                f"🪪 CPF / CNPJ: {doc}\n"
                f"📞 Telefone:   {phone}\n"
                f"✔️ Status:     {'Verificado' if verified else 'Pendente'}\n"
                f"{'─' * 45}\n"
                f"💰 Disponível: {Colors.BRIGHT_GREEN}R$ {avail_bal:.2f}{Colors.RESET}\n"
                f"🔒 Bloqueado:  {Colors.BRIGHT_YELLOW}R$ {block_bal:.2f}{Colors.RESET}"
            )
            print_box(content, color=Colors.BRIGHT_GREEN, title="PERFIL MASTER DA API")
        else:
            msg = data.get("message") or data.get("error") or "Erro desconhecido"
            print_status(f"Falha na consulta ({status_code}): {msg}", "error")

        pause()

    def generate_pix(self, current_username: str = "admin"):
        """Gera cobrança PIX instantânea. Ao ser paga, credita no saldo individual do usuário (descontando a taxa fixa de R$ 0,50)."""
        print_header("Cobrar via PIX", "Cobrança com Crédito em Saldo Individual")

        if not self.is_configured():
            print_status("Credenciais do Servidor não configuradas!", "warning")
            pause()
            return

        try:
            val_str = prompt_input("Valor a Cobrar em R$ (Ex: 10 ou 5.50)")
            amount = float(val_str.replace(",", "."))
            if amount <= 0:
                print_status("O valor deve ser maior que zero.", "error")
                pause()
                return
        except ValueError:
            print_status("Valor numérico inválido.", "error")
            pause()
            return

        net_val = max(0.0, amount - GATEWAY_FEE)
        print(f"\n 💵 {Colors.BOLD}Resumo da Cobrança:{Colors.RESET}")
        print(f"   Valor Solicitado:  {Colors.BRIGHT_WHITE}R$ {amount:.2f}{Colors.RESET}")
        print(f"   Taxa Gateway Fixa: {Colors.BRIGHT_YELLOW}R$ {GATEWAY_FEE:.2f}{Colors.RESET}")
        print(f"   Saldo a Creditar:  {Colors.BRIGHT_GREEN}R$ {net_val:.2f}{Colors.RESET}\n")

        initial_balance = 0.0
        st, udata = self.fetch_user_info()
        if st == 200 and "data" in udata:
            initial_balance = float(udata["data"].get("availableBalance", 0.0))

        payer_name = f"Cliente de {current_username}"
        payer_doc = "12999546424"
        description = f"Cobrança PIX - {current_username}"
        tx_id = f"tx_{uuid.uuid4().hex[:10]}"

        payload = {
            "amount": amount,
            "payerName": payer_name,
            "payerDocument": payer_doc,
            "transactionId": tx_id,
            "description": description
        }

        print_status("Gerando PIX com a Rede de Pagamentos...", "info")
        headers = self.get_headers()
        status_code, data = _make_request(f"{self.base_url}/transactions/create", method="POST", headers=headers, body=payload)

        if status_code in (200, 201) and "data" in data:
            tx_data = data["data"]
            copy_paste = tx_data.get("copyPaste", "N/A")
            api_tx_id = tx_data.get("transactionId", tx_id)
            state = tx_data.get("transactionState", "PENDENTE")

            save_transaction({
                "id": api_tx_id,
                "client_tx_id": tx_id,
                "tx_type": "CASHIN",
                "amount": amount,
                "payer_name": payer_name,
                "payer_doc": payer_doc,
                "description": description,
                "status": state,
                "copy_paste": copy_paste
            })

            send_native_notification("📥 PIX Gerado!", f"Cobrança de R$ {amount:.2f} gerada para {current_username}.")
            copied = _copy_to_clipboard(copy_paste)

            print(f"\n{Colors.BRIGHT_WHITE}{Colors.BOLD}  📱 QR CODE (ESCANEIE NO APP DO SEU BANCO):{Colors.RESET}\n")
            qr_display = render_qr_code(copy_paste)
            print(qr_display)

            print(f"\n{Colors.BRIGHT_CYAN}{Colors.BOLD}📋 CÓDIGO PIX COPIA E COLA:{Colors.RESET}")
            print(f"{Colors.BRIGHT_WHITE}{copy_paste}{Colors.RESET}\n")

            summary_box = (
                f"📌 ID:         {Colors.BOLD}{api_tx_id}{Colors.RESET}\n"
                f"💵 Valor Bruto: {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}\n"
                f"🏷️ Taxa Fixa:   {Colors.BRIGHT_YELLOW}R$ {GATEWAY_FEE:.2f}{Colors.RESET}\n"
                f"💰 Seu Crédito: {Colors.BRIGHT_GREEN}R$ {net_val:.2f}{Colors.RESET}\n"
                f"📊 Status:      {Colors.BRIGHT_YELLOW}{state}{Colors.RESET}"
            )
            print_box(summary_box, color=Colors.BRIGHT_GREEN, title="PIX GERADO COM SUCESSO")

            if copied:
                print_status("Código PIX copiado automaticamente!", "success")

            print(f"\n{Colors.BRIGHT_YELLOW}Iniciar monitoramento em tempo real do recebimento?{Colors.RESET}")
            mon_ans = prompt_input("Monitorar agora? (S/N)", default="S").upper()
            if mon_ans == "S":
                self.monitor_transaction(api_tx_id, amount, initial_balance=initial_balance, current_username=current_username)
            else:
                pause()
        else:
            msg = data.get("message") or data.get("error") or str(data)
            print_status(f"Falha ao gerar PIX ({status_code}): {msg}", "error")
            pause()

    def monitor_transaction(self, transaction_id: str, amount: float = 0.0, initial_balance: float = None, current_username: str = "admin"):
        """Monitora o recebimento do PIX. Ao ser pago, credita o saldo no banco do usuário."""
        print_header("Monitor de Recebimento PIX", f"ID: {transaction_id}")
        print_status("Monitorando recebimento a cada 3 segundos...", "info")
        print(f"{Colors.DIM}Pressione CTRL+C para cancelar e voltar ao menu.{Colors.RESET}\n")

        headers = self.get_headers()
        attempt = 0

        if initial_balance is None:
            st, udata = self.fetch_user_info()
            if st == 200 and "data" in udata:
                initial_balance = float(udata["data"].get("availableBalance", 0.0))
            else:
                initial_balance = 0.0

        last_known_balance = initial_balance

        try:
            while True:
                attempt += 1
                payment_confirmed = False

                st_usr, udata = self.fetch_user_info()
                if st_usr == 200 and "data" in udata:
                    last_known_balance = float(udata["data"].get("availableBalance", 0.0))
                    if last_known_balance > (initial_balance + 0.001):
                        payment_confirmed = True

                if not payment_confirmed:
                    check_url = f"{self.base_url}/transactions/check"
                    status_code, data = _make_request(check_url, method="POST", headers=headers, body={"transactionId": str(transaction_id)})
                    if status_code == 200:
                        tx_obj = data.get("transaction") or data.get("data", {})
                        state = "PENDENTE"
                        if isinstance(tx_obj, dict):
                            state = tx_obj.get("transactionState") or tx_obj.get("state") or tx_obj.get("status") or "PENDENTE"
                        elif isinstance(tx_obj, list) and len(tx_obj) > 0:
                            state = tx_obj[0].get("transactionState") or tx_obj[0].get("state") or "PENDENTE"
                        
                        if str(state).upper() in ["COMPLETO", "PAGO", "PAID", "APPROVED", "SUCESSO", "APROVADO", "COMPLETED"]:
                            payment_confirmed = True

                sys.stdout.write(f"\r{Colors.BRIGHT_YELLOW}[⏳ #{attempt}] Verificando recebimento...{Colors.RESET}   ")
                sys.stdout.flush()

                if payment_confirmed:
                    print("\n\n")
                    os.system("termux-vibrate -d 800 2>/dev/null")
                    os.system('termux-toast -s "Pagamento Recebido!" 2>/dev/null')

                    update_status(transaction_id, "COMPLETO")

                    ok_credit, msg_credit, new_user_bal = credit_user_balance_in_firebase(current_username, amount)
                    net_val = max(0.0, amount - GATEWAY_FEE)

                    send_native_notification(
                        "💰 PIX Recebido - Annonymous Bank",
                        f"Crédito de R$ {net_val:.2f} recebido na conta de {current_username}!"
                    )

                    success_msg = (
                        f"🎉 {Colors.BOLD}PAGAMENTO CONFIRMADO E CREDITADO!{Colors.RESET}\n\n"
                        f"📌 ID Transação:     {transaction_id}\n"
                        f"💵 Valor Cobrado:    R$ {amount:.2f}\n"
                        f"🏷️ Taxa Gateway:     R$ {GATEWAY_FEE:.2f}\n"
                        f"💰 Saldo Creditado:  {Colors.BRIGHT_GREEN}R$ {net_val:.2f}{Colors.RESET}\n"
                        f"🏦 Seu Saldo Atual:  {Colors.BRIGHT_GREEN}R$ {new_user_bal:.2f}{Colors.RESET}\n"
                        f"✅ Status:           {Colors.BRIGHT_GREEN}COMPLETO / CREDITADO{Colors.RESET}"
                    )
                    print_box(success_msg, color=Colors.BRIGHT_GREEN, title="RECEBIMENTO CONFIRMADO")
                    print_status("Os fundos foram creditados no seu saldo individual com sucesso!", "success")
                    
                    print(f"\n{Colors.BRIGHT_CYAN}Deseja voltar ao Menu Principal?{Colors.RESET}")
                    prompt_input("[ Pressione ENTER para retornar ao Menu Principal ]")
                    return

                time.sleep(3)

        except KeyboardInterrupt:
            print(f"\n\n{Colors.BRIGHT_YELLOW}Monitoramento cancelado.{Colors.RESET}")
            pause()

    def request_user_withdrawal(self, current_username: str):
        """Permite que um usuário comum solicite um saque do seu saldo individual."""
        print_header("Solicitar Saque / Resgate", "Transferência para sua Chave PIX")

        user_bal = get_user_balance_from_firebase(current_username)
        print(f" 💰 {Colors.BOLD}Seu Saldo Disponível para Saque:{Colors.RESET} {Colors.BRIGHT_GREEN}R$ {user_bal:.2f}{Colors.RESET}\n")

        if user_bal < 1.00:
            print_status("Saldo insuficiente! O valor mínimo para solicitar saque é R$ 1,00.", "error")
            pause()
            return

        try:
            val_str = prompt_input(f"Valor a Sacar em R$ (Disponível R$ {user_bal:.2f})")
            amount = float(val_str.replace(",", "."))
            if amount < 1.00:
                print_status("O valor mínimo para saque é R$ 1,00.", "error")
                pause()
                return
            if amount > user_bal:
                print_status(f"Valor maior que seu saldo disponível (R$ {user_bal:.2f}).", "error")
                pause()
                return
        except ValueError:
            print_status("Valor numérico inválido.", "error")
            pause()
            return

        print(f"\n{Colors.BOLD}Selecione o Tipo da sua Chave PIX:{Colors.RESET}")
        print(f"  [{Colors.BRIGHT_GREEN}1{Colors.RESET}] 🪪 CPF")
        print(f"  [{Colors.BRIGHT_GREEN}2{Colors.RESET}] 🏢 CNPJ")
        print(f"  [{Colors.BRIGHT_GREEN}3{Colors.RESET}] 📧 E-Mail")
        print(f"  [{Colors.BRIGHT_GREEN}4{Colors.RESET}] 📞 Telefone (DDD + Número)")
        print(f"  [{Colors.BRIGHT_GREEN}5{Colors.RESET}] 🔑 Chave Aleatória / EVP (UUID)")
        
        type_choice = prompt_input("\nOpção (1-5)", default="1")
        type_map = {"1": "CPF", "2": "CNPJ", "3": "EMAIL", "4": "TELEFONE", "5": "CHAVE_ALEATORIA"}

        if type_choice not in type_map:
            print_status("Tipo de chave PIX inválido.", "error")
            pause()
            return

        pix_type = type_map[type_choice]
        pix_key = prompt_input("Digite a sua Chave PIX")
        if not pix_key or not pix_key.strip():
            print_status("Chave PIX obrigatória.", "error")
            pause()
            return

        raw_key = pix_key.strip()
        clean_key = raw_key
        if pix_type in ("CPF", "CNPJ", "TELEFONE"):
            clean_key = re.sub(r'\D', '', raw_key)

        print(f"\n{Colors.BRIGHT_YELLOW}⚠️ CONFIRMAÇÃO DE SOLICITAÇÃO DE SAQUE:{Colors.RESET}")
        print(f" Solicitante:      {Colors.BOLD}{current_username}{Colors.RESET}")
        print(f" Valor a Sacar:    {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}")
        print(f" Chave PIX ({pix_type}): {Colors.BOLD}{clean_key}{Colors.RESET}")
        
        confirm = prompt_input("\nConfirmar solicitação? (SIM/NAO)", default="NAO").upper()
        if confirm != "SIM":
            print_status("Operação cancelada.", "warning")
            pause()
            return

        print_status("Enviando solicitação e reservando saldo...", "info")
        ok, msg, new_bal = create_withdrawal_request(current_username, amount, clean_key, pix_type, "Saque solicitado via app")

        if ok:
            send_native_notification("📤 Solicitação de Saque Enviada!", f"Saque de R$ {amount:.2f} aguardando aprovação do admin.")
            print_status(msg, "success")
            box_content = (
                f"👤 Usuário:          {current_username}\n"
                f"💵 Valor Solicitado: {Colors.BRIGHT_GREEN}R$ {amount:.2f}{Colors.RESET}\n"
                f"🔑 Chave PIX:        {clean_key} ({pix_type})\n"
                f"💰 Seu Novo Saldo:   {Colors.BRIGHT_GREEN}R$ {new_bal:.2f}{Colors.RESET}\n"
                f"📊 Status:           {Colors.BRIGHT_YELLOW}PENDENTE DE APROVAÇÃO ADMIN{Colors.RESET}"
            )
            print_box(box_content, color=Colors.BRIGHT_GREEN, title="SOLICITAÇÃO REGISTRADA")
        else:
            print_status(f"Falha na solicitação: {msg}", "error")
        pause()

    def send_pix_master_admin(self):
        """Saque Direto Master via Rede de Pagamentos (Exclusivo Administrador)."""
        print_header("Saque Direto Master", "Uso Exclusivo do Administrador")

        if not self.is_configured():
            print_status("Credenciais do Servidor não configuradas!", "warning")
            pause()
            return

        available_balance = 0.0
        st, udata = self.fetch_user_info()
        if st == 200 and "data" in udata:
            available_balance = float(udata["data"].get("availableBalance", 0.0))
            print(f" 💰 {Colors.BOLD}Saldo Master da Rede:{Colors.RESET} {Colors.BRIGHT_GREEN}R$ {available_balance:.2f}{Colors.RESET}\n")

        try:
            val_str = prompt_input("Valor em R$ (Mínimo R$ 1,00)")
            amount = float(val_str.replace(",", "."))
            if amount < 1.00:
                print_status("O valor mínimo é R$ 1,00.", "error")
                pause()
                return
        except ValueError:
            print_status("Valor numérico inválido.", "error")
            pause()
            return

        print(f"\n{Colors.BOLD}Selecione o Tipo da Chave PIX:{Colors.RESET}")
        print(" 1. CPF  │  2. CNPJ  │  3. E-Mail  │  4. Telefone  │  5. Chave Aleatória (EVP)")
        type_choice = prompt_input("\nOpção (1-5)", default="1")
        type_map = {"1": "CPF", "2": "CNPJ", "3": "EMAIL", "4": "TELEFONE", "5": "CHAVE_ALEATORIA"}
        if type_choice not in type_map: return
        pix_type = type_map[type_choice]

        pix_key = prompt_input(f"Digite a Chave PIX ({pix_type})")
        if not pix_key: return
        clean_key = re.sub(r'\D', '', pix_key.strip()) if pix_type in ("CPF", "CNPJ", "TELEFONE") else pix_key.strip()

        desc = prompt_input("Descrição", default="Saque Master Admin")

        confirm = prompt_input(f"Confirmar envio de R$ {amount:.2f} para {clean_key}? (SIM/NAO)", default="NAO").upper()
        if confirm != "SIM": return

        payload = {
            "amount": amount,
            "pixKey": clean_key,
            "pixKeyType": pix_type,
            "description": desc
        }

        print_status("Enviando solicitação à Rede de Pagamentos...", "info")
        headers = self.get_headers()
        status_code, data = _make_request(f"{self.base_url}/transactions/withdraw", method="POST", headers=headers, body=payload)

        if status_code in (200, 201, 202):
            tx_info = data.get("data", {})
            out_id = str(tx_info.get("transactionId") or tx_info.get("jobId") or f"out_{uuid.uuid4().hex[:10]}")
            print_status("Saque Master enviado à Rede com sucesso!", "success")
            print_box(f"ID: {out_id}\nValor: R$ {amount:.2f}\nChave: {clean_key}", color=Colors.BRIGHT_GREEN, title="SAQUE MASTER")
        elif status_code == 400 and ("saque pendente" in str(data).lower() or "pendente" in str(data).lower()):
            warn_msg = (
                f"⚠️ {Colors.BOLD}SAQUE PENDENTE EM ANDAMENTO!{Colors.RESET}\n\n"
                f"Já existe um saque solicitado anteriormente aguardando processamento.\n"
                f"Aguarde alguns segundos até que a fila seja processada antes de solicitar um novo PIX."
            )
            print_box(warn_msg, color=Colors.BRIGHT_YELLOW, title="REGRA DE PROCESSAMENTO DE SAQUE")
        else:
            msg = data.get("message") or str(data)
            print_status(f"Falha na API ({status_code}): {msg}", "error")
        pause()

    def check_transaction(self):
        """Consulta o status de uma transação específica via POST /api/transactions/check ou banco local."""
        print_header("Consultar Transação")

        if not self.is_configured():
            print_status("Credenciais não configuradas!", "warning")
            pause()
            return

        tx_id = prompt_input("Informe o ID da transação")
        if not tx_id:
            return

        local_tx = get_transaction_by_id(tx_id)
        if local_tx:
            content = (
                f"📌 ID:         {Colors.BOLD}{local_tx['id']}{Colors.RESET}\n"
                f"📊 Tipo:       {'RECEBIDO (CASH-IN)' if local_tx['tx_type'] == 'CASHIN' else 'ENVIADO (CASH-OUT)'}\n"
                f"💵 Valor:      {Colors.BRIGHT_GREEN}R$ {local_tx['amount']:.2f}{Colors.RESET}\n"
                f"👤 Pagador:    {local_tx.get('payer_name', 'N/A')}\n"
                f"🪪 CPF/CNPJ:   {local_tx.get('payer_doc', 'N/A')}\n"
                f"🔑 Chave PIX:  {local_tx.get('pix_key', 'N/A')}\n"
                f"📝 Descrição:  {local_tx.get('description', 'N/A')}\n"
                f"📅 Data/Hora:  {local_tx.get('created_at', 'N/A')}\n"
                f"✅ Status:     {Colors.BRIGHT_YELLOW}{local_tx.get('status', 'PENDENTE')}{Colors.RESET}"
            )
            print_box(content, color=Colors.BRIGHT_CYAN, title="Transação no Banco Local")

        print_status("Consultando Servidor da Rede...", "info")
        headers = self.get_headers()
        url = f"{self.base_url}/transactions/check"
        status_code, data = _make_request(url, method="POST", headers=headers, body={"transactionId": str(tx_id)})

        if status_code == 200:
            print_box(json.dumps(data, indent=2, ensure_ascii=False), color=Colors.BRIGHT_GREEN, title="Dados Oficiais da Rede")
            
            print(f"\n{Colors.BRIGHT_YELLOW}Deseja monitorar esta transação?{Colors.RESET}")
            ans = prompt_input("Monitorar agora? (S/N)", default="N").upper()
            if ans == "S":
                self.monitor_transaction(tx_id)
        else:
            if not local_tx:
                msg = data.get("message") or data.get("error") or str(data)
                print_status(f"Consulta falhou ({status_code}): {msg}", "error")
            pause()
