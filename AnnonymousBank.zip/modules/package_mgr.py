import os
import subprocess
from core.ui import Colors, print_header, print_status, prompt_input, pause

PACKAGES = {
    "1": ("Python 3 & Pip", "pkg install -y python python-pip"),
    "2": ("Node.js & NPM", "pkg install -y nodejs"),
    "3": ("Git & OpenSSH", "pkg install -y git openssh"),
    "4": ("ZSH & Curl & Wget", "pkg install -y zsh curl wget"),
    "5": ("HTOP & Neofetch/Fastfetch", "pkg install -y htop fastfetch"),
    "6": ("PHP & Composer", "pkg install -y php"),
    "7": ("C/C++ (clang, make)", "pkg install -y clang make"),
    "8": ("Neovim / Vim", "pkg install -y neovim vim"),
    "9": ("Termux API tools", "pkg install -y termux-api")
}

def run_package_manager():
    """Menu interativo para gerenciamento e instalação de pacotes no Termux."""
    while True:
        print_header("Termux - Gerenciador de Pacotes & Ferramentas")
        print("Selecione uma ferramenta para instalar ou gerenciar:\n")

        for key, (name, cmd) in PACKAGES.items():
            print(f"  [{Colors.BRIGHT_GREEN}{key}{Colors.RESET}] Instalar {Colors.BOLD}{name}{Colors.RESET}")
            
        print(f"\n  [{Colors.BRIGHT_CYAN}U{Colors.RESET}] Atualizar Todos os Pacotes (pkg update && pkg upgrade)")
        print(f"  [{Colors.BRIGHT_YELLOW}C{Colors.RESET}] Limpar Cache (apt clean && apt autoremove)")
        print(f"  [{Colors.BRIGHT_RED}0{Colors.RESET}] Voltar ao Menu Principal")

        choice = prompt_input("\nOpção", default="0").upper()

        if choice == "0":
            break
        elif choice == "U":
            print_status("Iniciando atualização completa do Termux...", "info")
            os.system("pkg update -y && pkg upgrade -y")
            print_status("Pacotes atualizados!", "success")
            pause()
        elif choice == "C":
            print_status("Limpando arquivos temporários e cache...", "info")
            os.system("apt clean -y && apt autoremove -y")
            print_status("Sistema limpo com sucesso!", "success")
            pause()
        elif choice in PACKAGES:
            name, cmd = PACKAGES[choice]
            print_status(f"Instalando {name}...", "info")
            os.system(cmd)
            print_status(f"{name} instalado com sucesso!", "success")
            pause()
        else:
            print_status("Opção inválida.", "error")
