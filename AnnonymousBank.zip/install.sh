#!/data/data/com.termux/files/usr/bin/bash

echo -e "\033[1;36m====================================================\033[0m"
echo -e "\033[1;32m         ANNONYMOUS BANK PIX SYSTEM v3.0            \033[0m"
echo -e "\033[1;36m====================================================\033[0m"
echo ""

echo -e "\033[1;33m[1/3] Instalando dependências e bibliotecas Python...\033[0m"
pkg update -y && pkg install -y python python-pip curl termux-api
pip install qrcode colorama

echo -e "\033[1;33m[2/3] Configurando permissões de execução...\033[0m"
chmod +x main.py

SCRIPT_PATH="$(pwd)/main.py"

echo -e "\033[1;33m[3/3] Registrando executáveis globais no Termux...\033[0m"
for BIN_NAME in "anon" "bank" "anonbank" "anonymous-bank" "tmenu" "mistic"; do
    TERMUX_BIN="$PREFIX/bin/$BIN_NAME"
    cat <<EOF > "$TERMUX_BIN"
#!/data/data/com.termux/files/usr/bin/sh
python "$SCRIPT_PATH" "\$@"
EOF
    chmod +x "$TERMUX_BIN"
done

# Adiciona alias no .bashrc e .zshrc para rodar em qualquer aba
for RC_FILE in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$RC_FILE" ]; then
        for ALIAS_NAME in "anon" "bank" "anonbank"; do
            if ! grep -q "alias $ALIAS_NAME=" "$RC_FILE"; then
                echo "alias $ALIAS_NAME='python $SCRIPT_PATH'" >> "$RC_FILE"
            fi
        done
    fi
done

echo ""
echo -e "\033[1;32m====================================================\033[0m"
echo -e "\033[1;32m ✔ INSTALAÇÃO CONCLUÍDA COM SUCESSO!                 \033[0m"
echo -e "\033[1;32m====================================================\033[0m"
echo -e "\033[1;37mVocê pode abrir o aplicativo em QUALQUER aba ou pasta digitando:\033[0m"
echo -e "\033[1;36m  anon \033[0m  ou  \033[1;36m bank \033[0m  ou  \033[1;36m anonbank \033[0m"
echo ""
